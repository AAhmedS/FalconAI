// import 'dart:math';
// import 'dart:developer' as dev;
// import 'package:geocoding/geocoding.dart';
// import 'package:geolocator/geolocator.dart';

// class LocationService {
//   static Future<bool> handleLocationPermission() async {
//     bool serviceEnabled;
//     LocationPermission permission;

//     serviceEnabled = await Geolocator.isLocationServiceEnabled();
//     if (!serviceEnabled) {
//       // Location services are disabled. Please enable the services
//       return false;
//     }
//     permission = await Geolocator.checkPermission();
//     if (permission == LocationPermission.denied) {
//       permission = await Geolocator.requestPermission();
//       if (permission == LocationPermission.denied) {
//         // Location permissions are denied
//         return false;
//       }
//     }
//     if (permission == LocationPermission.deniedForever) {
//       // Location permissions are permanently denied, we cannot request permissions.

//       return false;
//     }
//     return true;
//   }

//   static Future<Position?> getCurrentPosition() async {
//     try {
//       final hasPermission = await handleLocationPermission();
//       if (!hasPermission) return null;
//       Position position = await Geolocator.getCurrentPosition(
//         desiredAccuracy: LocationAccuracy.high,
//       );
//       dev.log(position.longitude.toString(), name: "longitude");
//       dev.log(position.latitude.toString(), name: "latitude");
//       CacheHelper.setLat(position.latitude);
//       CacheHelper.setLong(position.longitude);
//       return position;
//     } catch (e) {
//       return null;
//     }
//   }

//   static Future<String?> getAddressFromLatLng(
//       {required double latitude, required double longitude}) async {
//     try {
//       List<Placemark> placeMarks =
//           await placemarkFromCoordinates(latitude, longitude);
//       Placemark place = placeMarks[0];
//       CacheHelper.setAddressFromLatLng(
//           location:
//               "${place.country}, ${place.administrativeArea}, ${place.street}, ${place.postalCode}");
//       return "${place.street}, ${place.subLocality},${place.subAdministrativeArea}, ${place.postalCode}";
//     } catch (e) {
//       return null;
//     }
//   }

//   static Future<double> calculateDistance(
//       {required double targetLat, required double targetLng}) async {
//     var userLocation = await getCurrentPosition();
//     dev.log(targetLat.toString(), name: "slkdfjlsdkjflskdjf lat");
//     dev.log(targetLng.toString(), name: "slkdfjlsdkjflskdjf lng");
//     dev.log(userLocation!.latitude.toString(),
//         name: "slkdfjlsdkjflskdjf lat user");
//     dev.log(userLocation.latitude.toString(),
//         name: "slkdfjlsdkjflskdjf lng user");
//     double distanceInMeters = Geolocator.distanceBetween(
//         targetLng, userLocation.longitude, targetLat, userLocation.latitude);
//     double distanceInKilometers = distanceInMeters / 1000;
//     return distanceInKilometers;
//     // var userLocation = await getCurrentPosition();
//     // const double earthRadiusKm = 6371.0; // نصف قطر الأرض بالكيلومترات

//     // double dLat = _degreesToRadians(targetLat - userLocation!.latitude);
//     // double dLng = _degreesToRadians(targetLng - userLocation.longitude);

//     // double a = sin(dLat / 2) * sin(dLat / 2) +
//     //     cos(_degreesToRadians(userLocation.latitude)) *
//     //         cos(_degreesToRadians(targetLat)) *
//     //         sin(dLng / 2) *
//     //         sin(dLng / 2);

//     // double c = 2 * atan2(sqrt(a), sqrt(1 - a));

//     // double distanceKm = earthRadiusKm * c;

//     // // إذا كانت المسافة أقل من كيلومتر واحد، نعيدها بالمتر
//     // if (distanceKm < 1.0) {
//     //   return distanceKm * 1000; // نعيد المسافة بالمتر
//     // }

//     // return distanceKm; // نعيد المسافة بالكيلومترات
//   }

//   static double _degreesToRadians(double degrees) {
//     return degrees * pi / 180.0;
//   }

//   // static Future<void> getAddressFromLatLng(double latitude, double longitude) async {
//   //   try {
//   //     List<Placemark> placemarks = await placemarkFromCoordinates(latitude, longitude);

//   //     Placemark place = placemarks[0];

//   //     print("${place.country}, ${place.locality}, ${place.street}");
//   //   } catch (e) {
//   //     print(e);
//   //   }
//   // }
// }
