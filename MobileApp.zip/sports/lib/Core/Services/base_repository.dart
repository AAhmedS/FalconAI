import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:sports/Core/Services/custom_response.dart';
import 'package:sports/Core/errors/failuer.dart';
import 'package:sports/Core/network/network_info.dart';

class BaseRepository<T> {
  NetworkInfo networkInfo;
  BaseRepository({required this.networkInfo});
  Future<Either<Failuer, CustomResponse>> repository(
    Future dataSource, {
    Function(dynamic json)? fromJsonT,
  }) async {
    log(fromJsonT.runtimeType.toString(), name: "runtimeType");
    try {
      Response response = await dataSource;
      log("${response.data}", name: "response");
      log("${response.statusCode}", name: "statusCode");
      // if (response.data.runtimeType is List) {
      // log(response.data.toString(), name: "json");
      // }
      CustomResponse<T> data = CustomResponse.fromJson(
        {"data": response.data},
        (json) {
          log(response.data.toString(), name: "json");
          return fromJsonT ?? json;
        },
      );
      // log(data..toString(), name: "ssssssssssssssssssss");
      if (response.statusCode == 200) {
        log("-------------------------------------------");
        return right(data);
      } else {
        return left(ServerFailuer(message: data.message ?? "Error"));
      }
    } catch (error) {
      return left(ServerFailuer(message: error.toString()));
    }
  }
}
