// import 'package:dio/dio.dart';

// class ApiClientHelper{
// Dio dio = Dio(
//   BaseOptions(
//     validateStatus: (status) {
//       return status != null && status <= 500;
//     },
//   )
// );
//   post({required String url, required Map<String, dynamic> data, Map<String, dynamic>? queryParameters}) {
//     return dio.post(
//       url,
//       data: data,
//       queryParameters: queryParameters
//     );
//   }
//   get({required String url, Map<String, dynamic>? data, Map<String, dynamic>? queryParameters}){
//     return dio.get(
//       url,
//       data: data,
//       queryParameters: queryParameters,
//     );
//   }
//   put({required String url, required Map<String, dynamic> data, Map<String, dynamic>? queryParameters}){
//     return dio.put(
//       url,
//       data: data,
//       queryParameters: queryParameters,
//     );
//   }
//   delete({required String url, required Map<String, dynamic> data, Map<String, dynamic>? queryParameters}){
//     return dio.delete(
//       url,
//       data: data,
//       queryParameters: queryParameters,
//       options: Options(
//         headers: {

//         }
//       )
//     );
//   }
// }

import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:sports/Core/Services/api_client_helper.dart';
import 'package:sports/Core/Services/app_pref.dart';

class ApiClientHelperImp extends ApiClientHelper {
  Map<String, dynamic> baseHeaders = {};
  Dio dio = Dio(BaseOptions(
    validateStatus: (status) {
      return status != null && status <= 500;
    },
  ));
  @override
  Future delete(
      {required String url,
      Map<String, dynamic>? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false}) {
    return dio.delete(url,
        data: data,
        queryParameters: queryParameters,
        options: Options(
          headers: authorization(
            headers: headers,
            token: CacheHelper.getToken(),
          ),
        ));
  }

  @override
  Future get(
      {required String url,
      Map<String, dynamic>? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false}) {
    return dio.get(url,
        data: data,
        queryParameters: queryParameters,
        options: Options(
          headers: authorization(
            headers: headers,
            token: CacheHelper.getToken(),
          ),
        ));
  }

//
  @override
  Future post(
      {required String url,
      Object? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false}) {
    log(url);
    log(data.toString());
    return dio.post(url,
        data: data,
        queryParameters: queryParameters,
        options: Options(
          headers: authorization(
            headers: headers,
            token: CacheHelper.getToken(),
          ),
        ));
  }

// CacheHelper.getUserData()!.token.notNull()
  @override
  Future put(
      {required String url,
      Object? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false}) {
    return dio.put(url,
        data: data,
        queryParameters: queryParameters,
        options: Options(
          headers: authorization(
            headers: headers,
            token: CacheHelper.getToken(),
          ),
        ));
  }

  // @override
  Map<String, dynamic> authorization(
      {Map<String, dynamic>? headers, String? token}) {
    if (token != null) {
      baseHeaders.addAll({"Authorization": "Bearer $token"});
      if (headers != null) {
        baseHeaders.addAll(headers);
      }
    } else {
      if (headers != null) {
        baseHeaders.addAll(headers);
      }
    }
    return baseHeaders;
  }
}
