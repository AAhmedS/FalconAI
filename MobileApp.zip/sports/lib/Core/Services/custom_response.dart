class CustomResponse<T> {
  final String? message;
  final bool status;
  final T? data;
  CustomResponse({
    required this.message,
    required this.status,
    required this.data,
  });

  factory CustomResponse.fromJson(
      Map<String, dynamic> json, T Function(dynamic json) fromJsonT) {
    return CustomResponse<T>(
        message: json.containsKey("message")
            ? json['data']['message'] as String?
            : json['message'],
        status: (json['status'] as bool?) ?? false,
        data: json['data'] != null ? fromJsonT(json['data']) : null);
  }
}
