import 'dart:developer';
import 'package:shared_preferences/shared_preferences.dart';

class CacheHelper {
  static late SharedPreferences preferences;
  static init() async {
    preferences = await SharedPreferences.getInstance();
  }

  // static setUserData(UserDataModel model) {
  //   return setString(
  //       key: CustomHelper.USER_DATA, value: jsonEncode(model.toJson()));
  // }

  // static UserDataModel? getUserData() {
  //   return preferences.getString(CustomHelper.USER_DATA) != null
  //       ? UserDataModel.fromJson(jsonDecode(
  //           preferences.getString(CustomHelper.USER_DATA).notNull())!)
  //       : null;
  // }

  static removeUserData() {
    preferences.remove(CustomHelper.USER_DATA);
  }

  static setString({required String key, required String value}) {
    preferences.setString(key, value);
  }

  static setBool({required String key, required bool value}) {
    preferences.setBool(key, value);
  }

  static setInt({required String key, required int value}) {
    preferences.setInt(key, value);
  }

  static setDouble({required String key, required double value}) {
    preferences.setDouble(key, value);
  }

  static login() {
    preferences.setBool(CustomHelper.LOGIN, true);
  }

  static logout() {
    preferences.clear();
    preferences.remove(CustomHelper.TOKEN);
    preferences.remove(CustomHelper.USER_DATA);
    preferences.setBool(CustomHelper.LOGIN, false);
  }

  static checkLogin() {
    return preferences.getBool(CustomHelper.LOGIN) ?? false;
  }

  static checkHaveStore() {
    return preferences.getBool(CustomHelper.HAVE_STORE) ?? false;
  }

  static setHaveStore(bool value) {
    preferences.setBool(CustomHelper.HAVE_STORE, value);
  }

  //location
  static setLong(double value) {
    preferences.setDouble(CustomHelper.LONG, value);
  }

  static setLat(double value) {
    log(value.toString());
    preferences.setDouble(CustomHelper.LAT, value);
  }

  static double? getLong() {
    double? long = preferences.getDouble(CustomHelper.LONG);
    log('Retrieved Longitude: $long');
    return long;
  }

  static double? getLat() {
    double? lat = preferences.getDouble(CustomHelper.LAT);
    log('Retrieved Latitude: $lat');
    return lat;
  }

  static setAddressFromLatLng({required String location}) {
    preferences.setString(CustomHelper.AddressFromLatLng, location);
  }

  static getAddressFromLatLng() {
    return preferences.getString(CustomHelper.AddressFromLatLng);
  }

  static setToken({required String token}) {
    preferences.setString(CustomHelper.TOKEN, token);
  }

  static String getToken() {
    return preferences.getString(CustomHelper.TOKEN) ?? "kk";
  }

  static setUserId({required String userId}) {
    preferences.setString(CustomHelper.USER_ID, userId);
  }

  static String getUserId() {
    return preferences.getString(CustomHelper.USER_ID) ?? "";
  }

  static setRole({required String role}) {
    preferences.setString(CustomHelper.ROLE, role);
  }

  static String getRole() {
    return preferences.getString(CustomHelper.ROLE) ?? "";
  }
}

class CustomHelper {
  static String get LOGIN => "LOGIN";
  static String get USER_DATA => "USER_DATA";
  static String get TOKEN => "TOKEN";
  static String get USER_ID => "USER_ID";
  static String get ROLE => "ROLE";
  static String get USER_IMAGE => "USER_IMAGE";
  static String get HAVE_STORE => "HAVE_STORE";
  static String get LONG => "LONG";
  static String get LAT => "LAT";
  static String get AddressFromLatLng => "AddressFromLatLng";
}
