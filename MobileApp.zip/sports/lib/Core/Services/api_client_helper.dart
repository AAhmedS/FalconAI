abstract class ApiClientHelper {
  Future get(
      {required String url,
      Map<String, dynamic>? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false});
  Future post(
      {required String url,
      Object? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false});
  Future put(
      {required String url,
      Object? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false});
  Future delete(
      {required String url,
      Map<String, dynamic>? data,
      Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? headers,
      bool token = false});
}
