import 'package:get_it/get_it.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:sports/Core/Services/api_client_helper.dart';
import 'package:sports/Core/Services/api_client_helper_imp.dart';
import 'package:sports/Core/Services/base_repository.dart';
import 'package:sports/Core/network/network_info.dart';
import 'package:sports/Core/network/network_info_imp.dart';
import 'package:sports/Features/Authentication/data/data_source/authentication_data_source.dart';
import 'package:sports/Features/Authentication/data/repository/authentication_repository.dart';
import 'package:sports/Features/Authentication/presentation/cubit/authentication_cubit.dart';
import 'package:sports/Features/Coach/data/data_source/coach_data_source.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/absent_activites_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/activity_coash_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_activity%20_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_active_booking_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_activity_today_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_not_active_booking_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/mark_attendance_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/pass_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/player_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/present_activities_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/rate_player_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/sport_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/video_player_cubit.dart';
import 'package:sports/Features/Parent/data/data_source/parent_data_source.dart';
import 'package:sports/Features/Parent/data/repository/parent_repository.dart';
import 'package:sports/Features/Parent/presentation/cubit/add_player_cubit.dart';
import 'package:sports/Features/Parent/presentation/cubit/get_players_cubit.dart';
import 'package:sports/Features/Player/data/data_source/player_data_source.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_active_booking_player_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_not_active_booking_player_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_captain_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_sport_at_home_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_coachs_by_sport_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_news_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_sport_by_captian_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_sports_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_videos_cubit.dart';

final sl = GetIt.instance;

init() {
  ///===============================[ Blocs ]===============================\\\
  ///Authentication
  sl.registerFactory(
    () => AuthenticationCubit(repository: sl()),
  );

  ///Coach
  sl.registerFactory(
    () => ActivityCoashCubit(repository: sl()),
  );
  sl.registerFactory(
    () => CoachCubit(repository: sl()),
  );
  sl.registerFactory(
    () => GetAllActiveBookingCubit(repository: sl())..getAllBooking(),
  );
  sl.registerFactory(
    () => GetAllNotActiveBookingCubit(repository: sl())..getAllBooking(),
  );
  sl.registerFactory(
    () => GetAllActivityTodayCubit(repository: sl())..get(),
  );
  sl.registerFactory(() => PassCubit(repository: sl()));
  sl.registerFactory(
    () => MarkAttendanceCoachCubit(repository: sl()),
  );
  sl.registerFactory(
    () => PlayerCoachCubit(repository: sl()),
  );
  sl.registerFactory(
    () => RatePlayerCoachCubit(repository: sl()),
  );
  sl.registerFactory(
    () => SportCoachCubit(repository: sl()),
  );
  sl.registerFactory(
    () => GetAllActivityCubit(repository: sl()),
  );
  sl.registerFactory(
    () => VideoPlayerCubit(repository: sl()),
  );
  sl.registerFactory(
    () => PresentActivitiesCubit(repository: sl()),
  );
  sl.registerFactory(
    () => AbsentActivitesCubit(repository: sl()),
  );

  ///Player
  sl.registerFactory(
    () => GetSportsCubit(repository: sl())..getSports(),
  );
  sl.registerFactory(
    () => GetCoachsBySportCubit(repository: sl()),
  );
  sl.registerFactory(
    () => GetAllCaptainCubit(repository: sl())..get(),
  );
  sl.registerFactory(
    () => GetAllSportAtHomeCubit(repository: sl())..get(),
  );
  sl.registerFactory(
    () => GetSportByCaptianCubit(repository: sl()),
  );
  sl.registerFactory(
    () => GetNewsCubit(repository: sl())..get(),
  );
  sl.registerFactory(
    () => GetVideosCubit(repository: sl())..get(),
  );
  sl.registerFactory(
    () => GetAllActiveBookingPlayerCubit(repository: sl()),
  );
  sl.registerFactory(
    () => GetAllNotActiveBookingPlayerCubit(repository: sl()),
  );

  ///Parent
  sl.registerFactory(
    () => GetPlayersCubit(repository: sl())..get(),
  );
  sl.registerFactory(
    () => AddPlayerCubit(repository: sl()),
  );

  ///===============================[ Repository ]===============================\\\
  ///Authentication
  sl.registerLazySingleton(
    () => AuthenticationRepository(dataSource: sl()),
  );

  ///Coach
  sl.registerLazySingleton(
    () => CoachRepository(dataSource: sl(), baseRepository: sl()),
  );

  ///Player
  sl.registerLazySingleton(
    () => PlayerRepository(dataSource: sl(), baseRepository: sl()),
  );

  ///Parent
  sl.registerLazySingleton(
    () => ParentRepository(dataSource: sl(), baseRepository: sl()),
  );

  ///===============================[ DataSource ]===============================\\\
  ///Authentication
  sl.registerLazySingleton(
    () => AuthenticationDataSource(api: sl()),
  );

  ///Coach
  sl.registerLazySingleton(
    () => CoachDataSource(api: sl()),
  );

  ///Player
  sl.registerLazySingleton(
    () => PlayerDataSource(api: sl()),
  );

  ///Parent
  sl.registerLazySingleton(
    () => ParentDataSource(api: sl()),
  );

  ///===============================[ Global Usage ]===============================\\\
  // sl.registerLazySingleton<NetworkInfo>(
  //     () => NetworkInfoImp(internetConnectionChecker: sl()));
  sl.registerLazySingleton<NetworkInfo>(
    () => NetworkInfoImp(internetConnectionChecker: sl()),
  );
  sl.registerLazySingleton(
    () => InternetConnectionChecker(),
  );
  sl.registerLazySingleton<ApiClientHelper>(
    () => ApiClientHelperImp(),
  );
  sl.registerLazySingleton(
    () => BaseRepository(networkInfo: sl()),
  );
}
