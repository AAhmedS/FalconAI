import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Authentication/presentation/cubit/authentication_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/absent_activites_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/activity_coash_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_activity%20_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_active_booking_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_activity_today_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_not_active_booking_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/mark_attendance_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/pass_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/player_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/present_activities_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/rate_player_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/sport_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/video_player_cubit.dart';
import 'package:sports/Features/Parent/presentation/cubit/add_player_cubit.dart';
import 'package:sports/Features/Parent/presentation/cubit/get_players_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_active_booking_player_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_not_active_booking_player_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_captain_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_sport_at_home_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_coachs_by_sport_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_news_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_sport_by_captian_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_sports_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_videos_cubit.dart';
import 'injection_controller.dart' as di;

class AppProviders {
  static get() {
    return [
      BlocProvider(create: (context) => di.sl<AuthenticationCubit>()),
      BlocProvider(create: (context) => di.sl<ActivityCoashCubit>()),
      BlocProvider(create: (context) => di.sl<CoachCubit>()),
      BlocProvider(create: (context) => di.sl<GetAllActiveBookingCubit>()),
      BlocProvider(create: (context) => di.sl<GetAllNotActiveBookingCubit>()),
      BlocProvider(create: (context) => di.sl<MarkAttendanceCoachCubit>()),
      BlocProvider(create: (context) => di.sl<PlayerCoachCubit>()),
      BlocProvider(create: (context) => di.sl<RatePlayerCoachCubit>()),
      BlocProvider(create: (context) => di.sl<SportCoachCubit>()),
      BlocProvider(create: (context) => di.sl<GetAllActivityCubit>()),
      BlocProvider(create: (context) => di.sl<GetSportsCubit>()),
      BlocProvider(create: (context) => di.sl<VideoPlayerCubit>()),
      BlocProvider(create: (context) => di.sl<GetCoachsBySportCubit>()),
      BlocProvider(create: (context) => di.sl<GetAllCaptainCubit>()),
      BlocProvider(create: (context) => di.sl<GetSportByCaptianCubit>()),
      BlocProvider(create: (context) => di.sl<GetNewsCubit>()),
      BlocProvider(create: (context) => di.sl<GetVideosCubit>()),
      BlocProvider(
          create: (context) => di.sl<GetAllNotActiveBookingPlayerCubit>()),
      BlocProvider(
          create: (context) => di.sl<GetAllActiveBookingPlayerCubit>()),
      BlocProvider(create: (context) => di.sl<GetPlayersCubit>()),
      BlocProvider(create: (context) => di.sl<GetAllSportAtHomeCubit>()),
      BlocProvider(create: (context) => di.sl<AddPlayerCubit>()),
      BlocProvider(create: (context) => di.sl<PassCubit>()),
      BlocProvider(create: (context) => di.sl<GetAllActivityTodayCubit>()),
      BlocProvider(create: (context) => di.sl<PresentActivitiesCubit>()),
      BlocProvider(create: (context) => di.sl<AbsentActivitesCubit>()),
    ];
  }
}