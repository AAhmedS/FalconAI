import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField(
      {super.key,
      required this.hintText,
      this.label,
      required this.controller,
      this.validator,
      this.readOnly = false,
      this.onTap,
      this.keyboardType});
  final String hintText;
  final TextEditingController controller;
  final String? Function(String? value)? validator;
  final bool readOnly;
  final TextInputType? keyboardType;
  final String? label;
  final void Function()? onTap;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null)
          Column(
            children: [
              Text(
                label ?? "",
                style: const TextStyle(fontSize: 12, color: Color(0xff6C7278)),
              ),
              const Gap(5)
            ],
          ),
        TextFormField(
          controller: controller,
          validator: validator,
          readOnly: readOnly,
          onTap: onTap,
          keyboardType: keyboardType,
          style: const TextStyle(fontSize: 14),
          decoration: InputDecoration(
            contentPadding:
                const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            constraints: const BoxConstraints(minHeight: 45, maxHeight: 45),
            fillColor: const Color(0xFFF7F8F8),
            hintStyle: const TextStyle(fontSize: 14, color: Colors.grey),
            filled: true,
            border: InputBorder.none,
            enabledBorder: border(),
            focusedBorder: border(),
            disabledBorder: border(),
            hintText: hintText,
          ),
        ),
      ],
    );
  }

  border() {
    return OutlineInputBorder(
      borderRadius: BorderRadius.circular(15),
      borderSide: const BorderSide(color: Colors.black12),
    );
  }
}
