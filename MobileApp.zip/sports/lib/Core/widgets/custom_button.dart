import 'package:flutter/material.dart';
import 'package:multi_border/multi_border.dart';

class CustomButton extends StatelessWidget {
  const CustomButton({super.key, required this.text, this.onTap});
  final String text;
  final void Function()? onTap;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 48,
        decoration: MultiBorderDecoration(
            innerRadius: BorderRadius.circular(15),
            // borderRadius:
            color: const Color(0xff3B589D),
            borderSides: const [
              BorderSide(
                color: Color(0xff6178B0),
                width: 1,
              ),
              BorderSide(color: Color(0xff375CFA), width: 2),
            ]),
        child: Center(
          child: Text(
            text,
            style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.w900, color: Colors.white),
          ),
        ),
      ),
    );
  }
}
