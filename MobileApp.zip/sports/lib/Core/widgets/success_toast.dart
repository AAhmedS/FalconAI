import 'package:flutter/material.dart';
import 'package:toastification/toastification.dart';

successToast({required BuildContext context, required String message}) {
  return toastification.show(
      context: context,
      description: Text(
        message,
        style: const TextStyle(
          fontSize: 16,
          color: Colors.green,
        ),
      ),
      type: ToastificationType.success,
      autoCloseDuration: const Duration(seconds: 5));
}
