import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class SwapWidget extends StatefulWidget {
  const SwapWidget(
      {super.key,
      required this.firstTite,
      required this.secondTitle,
      required this.firstWidget,
      required this.secondWidget});
  final String firstTite;
  final String secondTitle;
  final Widget firstWidget;
  final Widget secondWidget;
  @override
  State<SwapWidget> createState() => _SwapWidgetState();
}

class _SwapWidgetState extends State<SwapWidget> {
  int selectedItem = 0;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          width: double.infinity,
          height: 65,
          decoration: BoxDecoration(
              color: const Color(0xFFF4F4F4),
              borderRadius: BorderRadius.circular(20)),
          child: Row(
            children: [
              Flexible(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedItem = 1;
                    });
                  },
                  child: Container(
                    height: 38,
                    decoration: BoxDecoration(
                      color: selectedItem == 0 ? null : const Color(0xFF325198),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Text(
                        widget.secondTitle,
                        style: TextStyle(
                          fontSize: 14,
                          color: selectedItem == 0
                              ? const Color(0xffB9B9B9)
                              : Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const Gap(20),
              Flexible(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedItem = 0;
                    });
                  },
                  child: Container(
                    height: 38,
                    decoration: BoxDecoration(
                      color: selectedItem == 1 ? null : const Color(0xFF325198),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Text(
                        widget.firstTite,
                        style: TextStyle(
                          fontSize: 14,
                          color: selectedItem == 1
                              ? const Color(0xffB9B9B9)
                              : Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        const Gap(30),
        selectedItem == 0 ? widget.firstWidget : widget.secondWidget
      ],
    );
  }
}
