import 'package:flutter/material.dart';
import 'package:toastification/toastification.dart';

errorToast({required BuildContext context, required String message}) {
  return toastification.show(
      context: context,
      description: Text(
        message,
        style: const TextStyle(fontSize: 16, color: Colors.red),
      ),
      type: ToastificationType.error,
      autoCloseDuration: const Duration(seconds: 5));
}
