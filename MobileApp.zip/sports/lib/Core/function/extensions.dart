// ignore_for_file: constant_identifier_names
const PASSWORD_REG =
    "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}\$";
const PHONE_NUMBER_REG = "01[0125][0-9]{8}";
const NAME_REG = r'^[a-zA-Z\u0600-\u06FF\s]+$';

extension ValidatorExtention on String? {
  String? isValid() {
    if (toString().trim().isEmpty) {
      return "مطلوب *";
    } else {
      return null;
    }
  }

  String? isValidDiscount() {
    if (toString().trim().isEmpty) {
      return "مطلوب *";
    } else {
      if (double.parse(notNull()) < 1 && double.parse(notNull()) > 0) {
        return null;
      } else {
        return "برجاء أدخال نسبة خصم مناسبة";
      }
    }
  }

  String? isNameValid() {
    if (toString().isEmpty) {
      return "مطلوب *";
    } else if (toString().trim().isEmpty) {
      return "يرجى إدخال اسم صحيح وعدم ترك حقل الاسم فارغًا.";
    } else {
      if (RegExp(NAME_REG).hasMatch(notNull()) == true) {
        return null;
      } else {
        return "يحتوي هذا الاسم على أحرف معينة غير مسموح بها";
      }
    }
  }

  String? isValidNum({String? message = "برجاء أدخال عدد مناسب"}) {
    if (isValid() != null) {
      return isValid();
    } else {
      if (int.parse(toString()) <= 0) {
        return message;
      } else {
        return null;
      }
    }
  }

  String? isValidDouble({String? message = "برجاء أدخال عدد مناسب"}) {
    if (isValid() != null) {
      return isValid();
    } else {
      if (double.parse(toString()) <= 0) {
        return message;
      } else {
        return null;
      }
    }
  }

  String? isPhoneNumberValid() {
    if (toString().isEmpty) {
      return "مطلوب *";
    } else {
      if (RegExp(PHONE_NUMBER_REG).hasMatch(notNull()) == true) {
        return null;
      } else {
        return "يجب عليك أدخال رقم هاتف صحيح";
      }
    }
  }

  String? isPasswordValid() {
    if (toString().isEmpty) {
      return "مطلوب *";
    } else {
      if (RegExp(PASSWORD_REG).hasMatch(notNull()) == true) {
        return null;
      } else {
        return "يجب أن تتكون كلمة المرور من الأقل 8 أحرف وتحتوي على حرف واحد صغير وحرف واحد كبير وحرف واحد رقم وحرف واحد خاص من بين الرموز التالية: @، \$، !، %، *، ؟، &. يرجى إعادة إدخال كلمة المرور وفقًا للمتطلبات المذكورة.";
      }
    }
  }

  String? isConfirmPasswordValid(String? value) {
    if (toString().isEmpty) {
      return "مطلوب *";
    } else {
      if (RegExp(PASSWORD_REG).hasMatch(notNull()) == true) {
        if (notNull().toString().compareTo(value.notNull()) == 0) {
          return null;
        } else {
          return "عذرًا، كلمة المرور وتأكيد كلمة المرور غير متطابقين. يرجى التأكد من كتابة نفس كلمة المرور في الحقلين المخصصين.";
        }
      } else {
        return "يجب أن تتكون كلمة المرور من الأقل 8 أحرف وتحتوي على حرف واحد صغير وحرف واحد كبير وحرف واحد رقم وحرف واحد خاص من بين الرموز التالية: @، \$، !، %، *، ؟، &. يرجى إعادة إدخال كلمة المرور وفقًا للمتطلبات المذكورة.";
      }
    }
  }

  bool isDate() {
    try {
      DateTime.parse(notNull());
      return true;
    } catch (e) {
      return false;
    }
  }

  DateTime toDate() {
    if (isDate() == true) {
      return DateTime.parse(notNull());
    } else {
      return DateTime.now();
    }
  }

  String notNull() {
    return this ?? "";
  }
}

extension NullBoolExtention on bool? {
  notNull() {
    return this ?? false;
  }
}

extension NullIntExtention on int? {
  notNull() {
    return this ?? 0;
  }
}

extension NullListExtention on List? {
  notNull() {
    return this ?? [];
  }
}

extension NullListOfObjectExtention on List<Object>? {
  notNull() {
    return this ?? [];
  }
}
