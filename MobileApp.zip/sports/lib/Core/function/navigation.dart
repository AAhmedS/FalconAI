import 'package:flutter/material.dart';

extension Navigation on BuildContext {
  push(
    Widget page,
  ) {
    Navigator.push(
        this,
        MaterialPageRoute(
          builder: (context) => page,
        ));
  }

  pop() {
    Navigator.of(this).pop();
  }

  pushAndRemoveUntil(Widget page, {bool fade = false}) {
    Navigator.pushAndRemoveUntil(
      this,
      MaterialPageRoute(
        builder: (context) => page,
      ),
      (route) => false,
    );
  }

  pushReplacement(Widget page, {bool fade = false, bool gest = false}) {
    Navigator.pushReplacement(
        this,
        MaterialPageRoute(
          builder: (context) => page,
        ));
  }
}
