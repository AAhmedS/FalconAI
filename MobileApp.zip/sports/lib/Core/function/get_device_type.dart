import 'package:device_preview/device_preview.dart';
import 'package:flutter/cupertino.dart';

enum OrientationType { Landscape, Portrait }

class DeviceInfoCustomer {
  DeviceType deviceType;
  OrientationType orientationType;
  DeviceInfoCustomer({required this.deviceType, required this.orientationType});
}

DeviceInfoCustomer getDeviceType(MediaQueryData mediaQueryData) {
  DeviceInfoCustomer deviceInfo = DeviceInfoCustomer(
      orientationType: OrientationType.Landscape, deviceType: DeviceType.phone);
  Orientation orientation = mediaQueryData.orientation;
  double width = 0;
  if (orientation == Orientation.landscape) {
    width = mediaQueryData.size.height;
    deviceInfo.orientationType = OrientationType.Landscape;
  } else {
    width = mediaQueryData.size.width;
    deviceInfo.orientationType = OrientationType.Portrait;
  }
  if (width >= 600) {
    deviceInfo.deviceType = DeviceType.tablet;
    return deviceInfo;
  } else {
    deviceInfo.deviceType = DeviceType.phone;
    return deviceInfo;
  }
}
