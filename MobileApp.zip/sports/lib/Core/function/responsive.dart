import 'dart:math';

import 'package:device_preview/device_preview.dart';
import 'package:flutter/material.dart';
import 'package:sports/Core/function/get_device_type.dart';

extension ResponsiveSize on int {
  responsive(context) {
    DeviceInfoCustomer deviceType = getDeviceType(MediaQuery.of(context));
    if (deviceType.deviceType == DeviceType.phone) {
      if (deviceType.orientationType == OrientationType.Landscape) {
        return this * MediaQuery.of(context).size.width * 0.0017;
      } else {
        return this * MediaQuery.of(context).size.width * 0.0035;
      }
    } else {
      if (deviceType.orientationType == OrientationType.Landscape) {
        return this * MediaQuery.of(context).size.width * 0.0024;
      } else {
        return this * MediaQuery.of(context).size.width * 0.0024;
      }
    }
  }
}

extension ResponsiveSizeDouble on double {
  responsive(context) {
    DeviceInfoCustomer deviceType = getDeviceType(MediaQuery.of(context));
    if (deviceType.deviceType == DeviceType.phone) {
      if (deviceType.orientationType == OrientationType.Landscape) {
        return this * MediaQuery.of(context).size.width * 0.0017;
      } else {
        return this * MediaQuery.of(context).size.width * 0.0035;
      }
    } else {
      if (deviceType.orientationType == OrientationType.Landscape) {
        return this * MediaQuery.of(context).size.width * 0.0024;
      } else {
        return this * MediaQuery.of(context).size.width * 0.0024;
      }
    }
  }
}

double getDeviceDouble(
    {required MediaQueryData mediaQueryData,
    required double mobile,
    required double tablet}) {
  DeviceInfoCustomer deviceInfoCustomer = getDeviceType(mediaQueryData);
  if (deviceInfoCustomer.deviceType == DeviceType.phone) {
    return mobile;
  } else {
    return tablet;
  }
}

class ScaleSize {
  static double textScaleFactor(BuildContext context,
      {double maxTextScaleFactor = 2}) {
    final width = MediaQuery.of(context).size.width;
    double val = (width / 1400) * maxTextScaleFactor;
    return max(1, min(val, maxTextScaleFactor));
  }

  static multiItemAtRow(BuildContext context,
      {defaultSiz = 2, double margin = 20.0}) {
    return (MediaQuery.of(context).size.width - margin.responsive(context)) /
        (defaultSiz * MediaQuery.of(context).size.width);
  }
}
