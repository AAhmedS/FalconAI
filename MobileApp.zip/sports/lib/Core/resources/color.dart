import 'package:flutter/material.dart';

class AppColor {
  static const Color primaryColor1 = Color(0xFF6610f2);
  static const Color primaryColor2 = Color(0xFF6610f2);
  static const Color gray1 = Color(0xFFB6B4C2);
}
