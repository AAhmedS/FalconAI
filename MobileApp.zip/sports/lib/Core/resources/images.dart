class AppImages {
  static const String onBoarding1 = "assets/on_boarding_1.png";
  static const String onBoarding2 = "assets/on_boarding_2.png";
  static const String onBoarding3 = "assets/on_boarding_3.png";
  static const String onBoarding4 = "assets/on_boarding_4.png";
  static const String logo = "assets/logo.png";
  static const String home = "assets/Home.png";
  static const String bookingIcon = "assets/booking_icon.png";
  static const String backgroundLogin = "assets/background_login.png";
  static const String calendarIcon = "assets/calendar_icon.png";
  static const String sportsIcon = "assets/sports_icon.png";
  static const String profileIcon = "assets/profile_icon.png";
  static const String logoutIcon = "assets/logout_icon.png";
}