class Endpoints {
  //########################################### Auth ########################################
  static const String baseUrl = "http://sports.somee.com/api";
  static const String login = "$baseUrl/Account/Login";
  static const String registerParent = "$baseUrl/Parent/RegisterParent";
  static const String registerChild = "$baseUrl/Child/RegisterChild";
  //########################################### Captain ########################################
  static const String getAllSportsForCaptain =
      "$baseUrl/Captain/GetAllSportsForCaptain";
  // static const String getAllBookingsCaptain = "$baseUrl/Captain/GetAllBookings";
  static const String getAllNotActiveBookings =
      "$baseUrl/Captain/GetAllNotActiveBookings";
  static const String getAllActiveBookings =
      "$baseUrl/Captain/GetAllActiveBookings";
  static const String getSportCaptain = "$baseUrl/Captain/GetSport";
  static const String getPlayerCaptain = "$baseUrl/Captain/GetPlayer";
  static const String getProfileCaptain = "$baseUrl/Captain/GetProfile";
  static const String updateProfileCaptain = "$baseUrl/Captain/UpdateProfile";
  static const String presentActivities = "$baseUrl/Captain/PresentActivities";
  static const String absentActivites = "$baseUrl/Captain/AbsentActivites";

  static const String getAllActivitiesForToday =
      "$baseUrl/Captain/GetAllActivitiesForToday";
  static const String getAllActivitiesCaptain =
      "$baseUrl/Captain/GetAllActivities";
  static const String getActivityCaptain = "$baseUrl/Captain/GetActivity";
  static const String addActivity = "$baseUrl/Captain/AddActivity";
  static const String updateActivity = "$baseUrl/Captain/UpdateActivity";
  static const String deleteActivity = "$baseUrl/Captain/DeleteActivity";
  static const String passFirstTest = "$baseUrl/Captain/PassFirstTest";
  static const String passSecondTest = "$baseUrl/Captain/PassSecondTest";
  static const String markAttendanceAsPresent =
      "$baseUrl/Captain/MarkAttendanceAsPresent";
  static const String markAttendanceAsAbsent =
      "$baseUrl/Captain/MarkAttendanceAsAbsent";
  static const String getRatePlayer = "$baseUrl/Captain/GetRatePlayer";
  static const String addRatePlayer = "$baseUrl/Captain/AddRatePlayer";
  static const String updateRatePlayer = "$baseUrl/Captain/UpdateRatePlayer";
  static const String getPlayerVideos = "$baseUrl/Captain/GetPlayerVideos";
  static const String addVideoToPlayer = "$baseUrl/Captain/AddVideoToPlayer";
  static const String updateVideoPlayer = "$baseUrl/Captain/UpdateVideoPlayer";
  static const String deleteVideoPlayer = "$baseUrl/Captain/DeleteVideoPlayer";

  //########################################### Parent ########################################
  static const String getPlayers = "$baseUrl/Parent/GetPlayers";
  static const String getPlayerParent = "$baseUrl/Parent/GetPlayer";
  static const String addNewPlayer = "$baseUrl/Parent/AddNewPlayer";
  static const String addExistPlayer = "$baseUrl/Parent/AddExistPlayer";
  static const String getRatePlayerParent = "$baseUrl/Parent/GetRatePlayer";
  static const String getProfileParent = "$baseUrl/Parent/GetProfile";
  static const String updateProfileParent = "$baseUrl/Parent/UpdateProfile";
  static const String getAllNotActiveBookingsForPlayer =
      "$baseUrl/Parent/GetAllNotActiveBookingsForPlayer";
  static const String getAllActiveBookingsForPlayer =
      "$baseUrl/Parent/GetAllActiveBookingsForPlayer";
  static const String getAllBookingsForPlayer =
      "$baseUrl/Parent/GetAllBookingsForPlayer";
  static const String getSport = "$baseUrl/Parent/GetSport";
  static const String getCaptainParent = "$baseUrl/Parent/GetCaptain";
  static const String getAllActivitiesForBooking =
      "$baseUrl/Parent/GetAllActivitiesForBooking";
  static const String getActivity = "$baseUrl/Parent/GetActivity";
  static const String getPlayerVideosParent = "$baseUrl/Parent/GetPlayerVideos";
  //########################################### Player ########################################
  static const String getAllBookingsPlayer = "$baseUrl/Player/GetAllBookings";
  static const String getSportPlayer = "$baseUrl/Player/GetSport";
  static const String getAllSportsAtHome = "$baseUrl/Account/GetAllSportsAtHome";
  static const String getAllSports = "$baseUrl/Dashboard/GetAllSports";
  static const String getProfilePlayer = "$baseUrl/Player/GetProfile";
  static const String updateProfilePlayer = "$baseUrl/Player/UpdateProfile";
  static const String getCaptainPlayer = "$baseUrl/Player/GetCaptain";
  static const String getAllActivitiesPlayer =
      "$baseUrl/Player/GetAllActivities";
  static const String getActivityPlayer = "$baseUrl/Player/GetActivity";
  static const String getProfile = "$baseUrl/Player/GetProfile";
  static const String getAllCaptainsBySport =
      "$baseUrl/Account/GetAllCaptainsBySport";
  static const String getAllCaptains = "$baseUrl/Account/GetAllCaptains";
  static const String getAllSportsByCaptain =
      "$baseUrl/Account/GetAllSportsByCaptain";
  static const String getAllNews = "$baseUrl/Account/GetAllNews";
  static const String getAllVideos = "$baseUrl/Account/GetAllVideos";

  static const String getAllActiveBookingsPlayer =
      "$baseUrl/Player/GetAllActiveBookings";
  static const String getRatePlayerPlayer = "$baseUrl/Player/GetRatePlayer";
  // static const String getAllVideos = "$baseUrl/Account/GetAllVideos";
  // static const String getAllVideos = "$baseUrl/Account/GetAllVideos";
}
