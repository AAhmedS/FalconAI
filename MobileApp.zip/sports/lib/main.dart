import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:sports/Core/Services/app_pref.dart';
import 'package:sports/Core/app/app_providers.dart';
import 'package:sports/Features/onBoarding/presentation/screens/splash_screen.dart';
import 'Core/app/injection_controller.dart' as di;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await CacheHelper.init();
  di.init();
  await initOneSignal();
// The promptForPushNotificationsWithUserResponse function will show the iOS or Android push notification prompt. We recommend removing the following code and instead using an In-App Message to prompt for notification permission

  runApp(const MyApp());
}

Future<void> initOneSignal() async {
  String id = OneSignal.User.pushSubscription.id??"NNNNNNNNNOOOOOOOOOOO";
  log(id.toString(), name: "OneSignalId");
  OneSignal.Notifications.requestPermission(true);
  OneSignal.Debug.setLogLevel(OSLogLevel.verbose);
  OneSignal.initialize("49457e9b-a43b-46e8-b691-fe92fc88f85c");
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    log(CacheHelper.getUserId(), name: "Token");
    log(CacheHelper.getToken(), name: "Token");
    log(CacheHelper.getRole(), name: "UserType");
    return MultiBlocProvider(
      providers: AppProviders.get(),
      child: MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            useMaterial3: true, scaffoldBackgroundColor: Colors.white),
        home: const SplashScreen(),
      ),
    );
  }
}
