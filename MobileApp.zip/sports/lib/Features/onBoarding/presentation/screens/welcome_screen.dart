import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/resources/color.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Features/onBoarding/presentation/screens/on_boarding_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              const Text.rich(TextSpan(children: [
                TextSpan(
                    text: "DIDPOOL",
                    style: TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.w900,
                        color: AppColor.primaryColor1)),
                TextSpan(
                    text: "Fit",
                    style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.w900,
                    )),
              ])),
              const Gap(15),
              const Text(
                "Everybody Can Train",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                  color: AppColor.gray1,
                ),
              ),
              const Spacer(),
              CustomButton(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => OnBoardingScreen(),
                    ),
                  );
                },
                text: "Get Started",
              ),
              const Gap(20),
            ],
          ),
        ),
      ),
    );
  }
}
