import 'package:flutter/material.dart';
import 'package:sports/Core/Services/app_pref.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Features/Authentication/presentation/screens/login_screen.dart';
import 'package:sports/Features/Coach/presentation/screens/nav_bar_coach.dart';
import 'package:sports/Features/Parent/presentation/screens/parent_nav_bar.dart';
import 'package:sports/Features/Player/presentation/screens/player_nav_bar.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(
      const Duration(seconds: 3),
      () {
        if (CacheHelper.checkLogin()) {
          if (CacheHelper.getRole() == "Captain") {
            if (mounted) {
              context.pushAndRemoveUntil(const NavBarCoach());
            }
          }
          if (CacheHelper.getRole() == "Player") {
            if (mounted) {
              context.pushAndRemoveUntil(const PlayerNavBar());
            }
          }
          if (CacheHelper.getRole() == "Parent") {
            if (mounted) {
              context.pushAndRemoveUntil(const ParentNavBar());
            }
          }
        } else {
          if (mounted) {
            context.pushAndRemoveUntil(const LoginScreen());
          }
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text("Splash"),
      ),
    );
  }
}
