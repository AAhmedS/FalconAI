import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/resources/color.dart';
import 'package:sports/Core/resources/images.dart';
import 'package:sports/Features/Authentication/presentation/screens/login_screen.dart';

// ignore: must_be_immutable
class OnBoardingScreen extends StatelessWidget {
  OnBoardingScreen({super.key});
  List<OnBoardingModel> onBoardinList = [
    OnBoardingModel(
        image: AppImages.onBoarding1,
        title: "Track Your Goal",
        subTitle:
            "Don't worry if you have trouble determining your goals, We can help you determine your goals and track your goals"),
    OnBoardingModel(
      image: AppImages.onBoarding2,
      title: "Get Burn",
      subTitle:
          "Let’s keep burning, to achive yours goals, it hurts only temporarily, if you give up now you will be in pain forever",
    ),
    OnBoardingModel(
      image: AppImages.onBoarding3,
      title: "Eat Well",
      subTitle:
          "Let's start a healthy lifestyle with us, we can determine your diet every day. healthy eating is fun",
    ),
    OnBoardingModel(
      image: AppImages.onBoarding4,
      title: "Improve Sleep  Quality",
      subTitle:
          "Improve the quality of your sleep with us, good quality sleep can bring a good mood in the morning",
    ),
  ];
  PageController controller = PageController();
  int currentPage = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            flex: 8,
            child: PageView.builder(
              controller: controller,
              itemCount: onBoardinList.length,
              itemBuilder: (context, index) {
                currentPage = index;
                log(currentPage.toString());
                return Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Image.asset(
                        onBoardinList[index].image,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const Gap(40),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            onBoardinList[index].title,
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const Gap(15),
                          Text(
                            onBoardinList[index].subTitle,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                              color: AppColor.gray1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          const Spacer(),
          Align(
            alignment: Alignment.centerRight,
            child: GestureDetector(
              onTap: () {
                log((currentPage).toString());
                if (currentPage == onBoardinList.length - 1) {
                  log((onBoardinList.length - 1).toString());
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LoginScreen(),
                    ),
                  );
                } else {
                  controller.nextPage(
                    duration: const Duration(milliseconds: 500),
                    curve: Curves.ease,
                  );
                }
              },
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                width: 60,
                height: 60,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [
                    AppColor.primaryColor2,
                    AppColor.primaryColor1,
                  ]),
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
          const Gap(30),
        ],
      ),
    );
  }
}

class OnBoardingModel {
  final String image;
  final String title;
  final String subTitle;

  OnBoardingModel(
      {required this.image, required this.title, required this.subTitle});
}
