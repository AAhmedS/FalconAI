import 'package:dartz/dartz.dart';
import 'package:sports/Core/Services/base_repository.dart';
import 'package:sports/Core/errors/failuer.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Parent/data/data_source/parent_data_source.dart';
import 'package:sports/Features/Parent/models/player_model.dart';
import 'package:sports/Features/Parent/models/player_response_model.dart';

class ParentRepository {
  final ParentDataSource dataSource;
  final BaseRepository baseRepository;

  ParentRepository({required this.dataSource, required this.baseRepository});

  Future<Either<Failuer, List<PlayerResponseModel>>> getPlayers() async {
    var response = await baseRepository.repository(dataSource.getPlayers());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<PlayerResponseModel> list = (r.data as List)
            .map(
              (e) => PlayerResponseModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getAllBookings(
      {required int playerId}) async {
    var response = await baseRepository.repository(
        dataSource.getAllActiveBookingsForPlayer(playerId: playerId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<ActivityModel>>> getAllActivitiesForBooking(
      {required int bookingId}) async {
    var response = await baseRepository.repository(
        dataSource.getAllActivitiesForBooking(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<ActivityModel> list = (r.data as List)
            .map(
              (e) => ActivityModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, String>> addExistPlayer(
      {required String serialNumber}) async {
    var response = await baseRepository
        .repository(dataSource.addExistPlayer(serialNumber: serialNumber));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? "Success");
      },
    );
  }

  Future<Either<Failuer, String>> addNewPlayer(
      {required PlayerParentModel model}) async {
    var response =
        await baseRepository.repository(dataSource.addNewPlayer(model: model));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? "Success");
      },
    );
  }
  // Future<Either<Failuer, String>> getRatePlayer({required int bookingId}) async {
  //   var response = await baseRepository.repository(dataSource.getRatePlayer(bookingId: bookingId));
  //   return response.fold(
  //     (l) {
  //       return left(l);
  //     },
  //     (r) {
  //       // List<BookingModel> list = (r.data as List).map((e) => BookingModel.fromJson(e),).toList();
  //       return right("Success");
  //     },
  //   );
  // }
  // Future<Either<Failuer, List<SportModel>>> getAllSports() async {
  //   var response = await baseRepository.repository(dataSource.getAllSports());
  //   return response.fold(
  //     (l) {
  //       return left(l);
  //     },
  //     (r) {
  //       List<SportModel> list = (r.data as List).map((e) => SportModel.fromJson(e),).toList();
  //       return right(list);
  //     },
  //   );
  // }
}

// getSportPlayer({required int sportId}) {
//   return api.get(
//       url: Endpoints.getSportPlayer, queryParameters: {"SportId": sportId});
// }
// getCaptainPlayer({required int captainId}) {
//   return api.get(
//       url: Endpoints.getCaptainPlayer,
//       queryParameters: {"CaptainId": captainId});
// }

// getAllActivitiesPlayer({required int bookingId}) {
//   return api.get(
//       url: Endpoints.getAllActivitiesPlayer,
//       queryParameters: {"BookingId": bookingId});
// }

// getActivity({required int activityId}) {
//   return api.get(url: Endpoints.getAllActivitiesPlayer);
// }

// getProfile() {
//   return api.get(url: Endpoints.getAllActivitiesPlayer);
// }

// getPlayerVideos() {
//   return api.get(url: Endpoints.getPlayerVideos);
// }

// getAllcaptain() {
//   return api.get(url: Endpoints.getAllCaptains);
// }

// getAllSportByCaptian({required String captainId}) {
//   return api.get(
//       url: Endpoints.getAllSportsByCaptain,
//       queryParameters: {"CaptainId": captainId});
// }

// getCaptionBySport({required int sportId}) {
//   return api.get(
//       url: Endpoints.getAllCaptainsBySport,
//       queryParameters: {"SportId": sportId});
// }

// getNews() {
//   return api.get(url: Endpoints.getAllNews);
// }

// getVideos() {
//   return api.get(url: Endpoints.getAllVideos);
// }
