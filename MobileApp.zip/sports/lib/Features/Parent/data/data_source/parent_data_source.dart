import 'package:dio/dio.dart';
import 'package:sports/Core/Services/api_client_helper.dart';
import 'package:sports/Core/resources/endpoints.dart';
import 'package:sports/Features/Parent/models/player_model.dart';

class ParentDataSource {
  final ApiClientHelper api;

  ParentDataSource({required this.api});

  getPlayers() {
    return api.get(url: Endpoints.getPlayers);
  }

  addExistPlayer({required String serialNumber}) {
    return api.get(
        url: Endpoints.addExistPlayer,
        queryParameters: {"SerialNumber": serialNumber});
  }

  addNewPlayer({required PlayerParentModel model}) async {
    var json = model.register();
    if (model.photo != null) {
      json["Photo"] = await MultipartFile.fromFile(model.photo!.path);
    }
    FormData formData = FormData.fromMap(json);
    return api.post(url: Endpoints.addNewPlayer, data: formData);
  }

  getAllBookingsForPlayer({required int playerId}) {
    return api.get(
        url: Endpoints.getAllBookingsForPlayer,
        queryParameters: {"PlayerId": playerId});
  }

  getAllActiveBookingsForPlayer({required int playerId}) {
    return api.get(
        url: Endpoints.getAllActiveBookingsForPlayer,
        queryParameters: {"PlayerId": playerId});
  }

  getRatePlayerParent({required int bookingId}) {
    return api.get(
        url: Endpoints.getRatePlayerParent,
        queryParameters: {"BookingId": bookingId});
  }

  getAllActivitiesForBooking({required int bookingId}) {
    return api.get(
        url: Endpoints.getAllActivitiesForBooking,
        queryParameters: {"BookingId": bookingId});
  }

  getPlayerVideosParent({required String bookingId}) {
    return api.get(
        url: Endpoints.getPlayerVideosParent,
        queryParameters: {"BookingId": bookingId});
  }

  // GetAllBookingsForPlayer
}
