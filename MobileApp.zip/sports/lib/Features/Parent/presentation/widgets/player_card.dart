import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Features/Parent/models/player_response_model.dart';

class PlayerCard extends StatelessWidget {
  const PlayerCard({super.key, required this.model});
  final PlayerResponseModel model;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      // ont
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
            color: Colors.white,
            // boxShadow: const [
            //   BoxShadow(color: Colors.black38, blurRadius: 10)
            // ],
            borderRadius: BorderRadius.circular(20)),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.red,
                  image: DecorationImage(
                      image: NetworkImage("https://t3.ftcdn.net/jpg/03/70/29/26/240_F_370292674_QS5nA0bJgyRD6VzYycTQdSWhhSHQJbQZ.jpg"), fit: BoxFit.cover,)),
            ),
            const Gap(20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(model.fullName ?? ""),
                const Gap(4),
                Text(model.email ?? ""),
              ],
            ),
            const Spacer(),
            Text("${model.age} Year")
          ],
        ),
      ),
    );
  }
}
