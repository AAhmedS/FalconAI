import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/resources/color.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Parent/presentation/cubit/add_player_cubit.dart';
import 'package:sports/Features/Parent/presentation/cubit/get_players_cubit.dart';
import 'package:sports/Features/Parent/presentation/cubit/parent_cubit.dart';
import 'package:sports/Features/Parent/presentation/screens/add_player_screen.dart';
import 'package:sports/Features/Parent/presentation/widgets/player_card.dart';

class PlayersScreen extends StatefulWidget {
  const PlayersScreen({super.key});

  @override
  State<PlayersScreen> createState() => _PlayersScreenState();
}

class _PlayersScreenState extends State<PlayersScreen> {
  TextEditingController serialNumber = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: GestureDetector(
        onTap: () {
          showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomButton(
                        onTap: () {
                          context.push(const AddPlayerScreen());
                        },
                        text: "Add New Player"),
                    const Gap(10),
                    CustomButton(
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                content:
                                    BlocConsumer<AddPlayerCubit, ParentState>(
                                  listener: (context, state) {
                                    if (state is FailureParentState) {
                                      errorToast(
                                          context: context,
                                          message: state.message);
                                    }
                                    if (state is SuccessAddPlayerState) {
                                      context.pop();
                                      context.read<GetPlayersCubit>().get();
                                      successToast(
                                          context: context,
                                          message: "Success Add Player");
                                    }
                                  },
                                  builder: (context, state) {
                                    return Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        CustomTextField(
                                          controller: serialNumber,
                                          hintText: "Serial Number",
                                          validator: (value) {
                                            if (value == null ||
                                                value.isEmpty) {
                                              return "This field is required.";
                                            }
                                            return null;
                                          },
                                        ),
                                        const Gap(30),
                                        CustomButton(
                                          onTap: () {
                                            if (formKey.currentState!
                                                .validate()) {
                                              context
                                                  .read<AddPlayerCubit>()
                                                  .addExist(
                                                      serialNumber:
                                                          serialNumber.text);
                                            }
                                          },
                                          text: "Add",
                                        )
                                      ],
                                    );
                                  },
                                ),
                              );
                            },
                          );
                        },
                        text: "Add Exist Player"),
                  ],
                ),
              );
            },
          );
        },
        child: Container(
          width: 50,
          height: 50,
          decoration: const BoxDecoration(
              shape: BoxShape.circle, color: AppColor.primaryColor1),
          child: const Center(
            child: Icon(
              Icons.add,
              color: Colors.white,
            ),
          ),
        ),
      ),
      body: BlocBuilder<GetPlayersCubit, ParentState>(
        builder: (context, state) {
          if (state is LoadingParentState) {
            return const LoadingWidget();
          }
          if (state is SuccessGetPlayersState) {
            return Container(
              margin: const EdgeInsets.only(top: 10),
              child: SingleChildScrollView(
                child: Column(
                  children: state.list.map(
                    (e) {
                      return PlayerCard(model: e);
                    },
                  ).toList(),
                ),
              ),
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }
}
