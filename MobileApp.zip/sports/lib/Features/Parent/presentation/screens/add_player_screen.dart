import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Parent/models/player_model.dart';
import 'package:sports/Features/Parent/presentation/cubit/add_player_cubit.dart';
import 'package:sports/Features/Parent/presentation/cubit/parent_cubit.dart';

class AddPlayerScreen extends StatefulWidget {
  const AddPlayerScreen({super.key});

  @override
  State<AddPlayerScreen> createState() => _AddPlayerScreenState();
}

class _AddPlayerScreenState extends State<AddPlayerScreen> {
  TextEditingController fullName = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController age = TextEditingController();
  TextEditingController gender = TextEditingController();
  TextEditingController password = TextEditingController();
  File? image;
  GlobalKey<FormState> formKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<AddPlayerCubit, ParentState>(
        listener: (context, state) {
          if (state is FailureParentState) {
            errorToast(context: context, message: state.message);
          }
          if (state is SuccessAddPlayerState) {
            successToast(context: context, message: "Success Add Player");
          }
        },
        builder: (context, state) {
          if (state is LoadingParentState) {
            return const LoadingWidget();
          }
          return SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                children: [
                  const Gap(60),
                  GestureDetector(
                    onTap: () async {
                      var pickedImage = await ImagePicker()
                          .pickImage(source: ImageSource.gallery);
                      if (pickedImage != null) {
                        image = File(pickedImage.path);
                        setState(() {});
                      }
                    },
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(),
                          image: image == null
                              ? null
                              : DecorationImage(
                                  image: FileImage(image!),
                                  fit: BoxFit.cover,
                                )),
                    ),
                  ),
                  const Gap(30),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        CustomTextField(
                          controller: fullName,
                          hintText: "Full Name",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "This field is required.";
                            }
                            return null;
                          },
                        ),
                        const Gap(30),
                        CustomTextField(
                          controller: email,
                          hintText: "Email",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "This field is required.";
                            }
                            return null;
                          },
                        ),
                        const Gap(30),
                        CustomTextField(
                          keyboardType: TextInputType.number,
                          controller: age,
                          hintText: "Age",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "This field is required.";
                            }
                            return null;
                          },
                        ),
                        const Gap(30),
                        CustomTextField(
                          controller: gender,
                          hintText: "Gender",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "This field is required.";
                            }
                            return null;
                          },
                        ),
                        const Gap(30),
                        CustomTextField(
                          controller: password,
                          hintText: "Password",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "This field is required.";
                            }
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),
                  const Gap(30),
                  Padding(
                    padding: const EdgeInsets.all(15),
                    child: CustomButton(
                      onTap: () {
                        if (formKey.currentState?.validate() == true) {
                          context.read<AddPlayerCubit>().addNew(
                              model: PlayerParentModel(
                                  age: int.tryParse(age.text) ?? 0,
                                  email: email.text,
                                  fullName: fullName.text,
                                  gender: 1,
                                  password: password.text,
                                  photo: image));
                        }
                      },
                      text: "Add",
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
