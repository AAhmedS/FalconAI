import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Parent/data/repository/parent_repository.dart';
import 'package:sports/Features/Parent/presentation/cubit/parent_cubit.dart';

class GetAllActivityCubit extends Cubit<ParentState> {
  final ParentRepository repository;
  GetAllActivityCubit({required this.repository}) : super(ParentInitial());
  get({required int bookingId}) async {
    emit(LoadingParentState());
    var response =
        await repository.getAllActivitiesForBooking(bookingId: bookingId);
    response.fold(
      (l) {
        emit(FailureParentState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllActivities(list: r));
      },
    );
  }
}
