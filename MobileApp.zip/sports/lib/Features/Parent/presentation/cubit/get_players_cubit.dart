import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Parent/data/repository/parent_repository.dart';
import 'package:sports/Features/Parent/presentation/cubit/parent_cubit.dart';

class GetPlayersCubit extends Cubit<ParentState> {
  final ParentRepository repository;
  GetPlayersCubit({required this.repository}) : super(ParentInitial());
  get() async {
    var resposne = await repository.getPlayers();
    resposne.fold(
      (l) {
        emit(FailureParentState(message: l.message));
      },
      (r) {
        emit(SuccessGetPlayersState(list: r));
      },
    );
  }
}
