import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Parent/data/repository/parent_repository.dart';
import 'package:sports/Features/Parent/models/player_model.dart';
import 'package:sports/Features/Parent/presentation/cubit/parent_cubit.dart';

class AddPlayerCubit extends Cubit<ParentState> {
  final ParentRepository repository;
  AddPlayerCubit({required this.repository}) : super(ParentInitial());
  addNew({required PlayerParentModel model}) async {
    emit(LoadingParentState());
    var response = await repository.addNewPlayer(model: model);
    response.fold(
      (l) {
        emit(FailureParentState(message: l.message));
      },
      (r) {
        emit(SuccessAddPlayerState());
      },
    );
  }

  addExist({required String serialNumber}) async {
    emit(LoadingParentState());
    var response = await repository.addExistPlayer(serialNumber: serialNumber);
    response.fold(
      (l) {
        emit(FailureParentState(message: l.message));
      },
      (r) {
        emit(SuccessAddPlayerState());
      },
    );
  }
}
