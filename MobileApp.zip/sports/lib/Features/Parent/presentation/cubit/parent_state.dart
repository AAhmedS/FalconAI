part of 'parent_cubit.dart';

@immutable
sealed class ParentState {}

final class ParentInitial extends ParentState {}

class SuccessGetAllBookingState extends ParentState {
  final List<BookingModel> list;

  SuccessGetAllBookingState({required this.list});
}

class SuccessGetAllActivities extends ParentState {
  final List<ActivityModel> list;

  SuccessGetAllActivities({required this.list});
}

class FailureParentState extends ParentState {
  final String message;

  FailureParentState({required this.message});
}

class LoadingParentState extends ParentState {}

class SuccessGetPlayersState extends ParentState {
  final List<PlayerResponseModel> list;

  SuccessGetPlayersState({required this.list});
}

class SuccessAddPlayerState extends ParentState {}
