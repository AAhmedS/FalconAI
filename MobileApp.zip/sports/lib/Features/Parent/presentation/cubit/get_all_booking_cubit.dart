import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Parent/data/repository/parent_repository.dart';
import 'package:sports/Features/Parent/presentation/cubit/parent_cubit.dart';

class GetAllBookingCubit extends Cubit<ParentState> {
  final ParentRepository repository;
  GetAllBookingCubit({required this.repository}) : super(ParentInitial());
  get({required int playerId}) async {
    emit(LoadingParentState());
    var response = await repository.getAllBookings(playerId: playerId);
    response.fold(
      (l) {
        emit(FailureParentState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllBookingState(list: r));
      },
    );
  }
}
