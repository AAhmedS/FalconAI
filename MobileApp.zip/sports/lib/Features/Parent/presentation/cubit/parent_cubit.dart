import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Parent/models/player_response_model.dart';

part 'parent_state.dart';

class ParentCubit extends Cubit<ParentState> {
  ParentCubit() : super(ParentInitial());
}
