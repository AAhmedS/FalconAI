import 'dart:io';

class PlayerParentModel {
  String? email;
  String? fullName;
  File? photo;
  int? age;
  int? gender;
  String? password;

  PlayerParentModel({
    this.age,
    this.email,
    this.fullName,
    this.gender,
    this.password,
    this.photo,
  });

  register() {
    return {
      "Email": email,
      "FullName": fullName,
      "Age": age,
      "Gender": gender,
      "Password": password,
    };
  }
}
