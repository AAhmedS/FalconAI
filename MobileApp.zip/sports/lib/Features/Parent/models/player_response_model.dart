class PlayerResponseModel {
  String? id;
  String? fullName;
  dynamic photo;
  String? email;
  int? age;

  PlayerResponseModel({
    this.id,
    this.fullName,
    this.photo,
    this.email,
    this.age,
  });

  factory PlayerResponseModel.fromJson(Map<String, dynamic> json) {
    return PlayerResponseModel(
      id: json['id'] as String?,
      fullName: json['fullName'] as String?,
      photo: json['photo'] as dynamic,
      email: json['email'] as String?,
      age: json['age'] as int?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'fullName': fullName,
        'photo': photo,
        'email': email,
        'age': age,
      };
}
