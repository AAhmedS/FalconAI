import 'dart:io';

class RegisterStudentRequestModel {
  final String email;
  final String fullName;
  final File? photo;
  final int age;
  final int gender;
  final String password;

  RegisterStudentRequestModel({
    required this.email,
    required this.fullName,
    this.photo,
    required this.age,
    required this.gender,
    required this.password,
  });

  register() {
    return {
      "Email": email,
      "Age": age,
      "Gender": gender,
      "Password": password,
    };
  }
}
