class RegisterParentRequestModel {
  final String fullName;
  final String phoneNumber;
  final String email;
  final String iDNumber;
  final String registerNumber;
  final int gender;
  final String password;

  RegisterParentRequestModel({
    required this.fullName,
    required this.phoneNumber,
    required this.email,
    required this.iDNumber,
    required this.registerNumber,
    required this.gender,
    required this.password,
  });
  reigster() {
    return {
      "FullName": fullName,
      "PhoneNumber": phoneNumber,
      "Email": email,
      "IDNumber": iDNumber,
      "RegisterNumber": registerNumber,
      "Gender": gender,
      "Password": password,
    };
  }
}
