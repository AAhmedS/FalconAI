import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:sports/Core/Services/api_client_helper.dart';
import 'package:sports/Core/resources/endpoints.dart';
import 'package:sports/Features/Authentication/data/models/register_parent_request_model.dart';
import 'package:sports/Features/Authentication/data/models/register_student_request_model.dart';

class AuthenticationDataSource {
  final ApiClientHelper api;

  AuthenticationDataSource({required this.api});

  Future login({required String email, required String password}) {
    return api.post(
      url: Endpoints.login,
      data: FormData.fromMap({
        "Email": email,
        "Password": password,
      }),
    );
  }

  Future registerParent({required RegisterParentRequestModel model}) {
    log(model.reigster().toString());
    return api.post(
        url: Endpoints.registerParent,
        data: FormData.fromMap(model.reigster()));
  }

  Future registerChild({required RegisterStudentRequestModel model}) async {
    var data = model.register();
    if (model.photo != null) {
      data['Photo'] = await MultipartFile.fromFile(model.photo!.path);
    }
    return api.post(url: Endpoints.registerChild, data: FormData.fromMap(data));
  }
}
