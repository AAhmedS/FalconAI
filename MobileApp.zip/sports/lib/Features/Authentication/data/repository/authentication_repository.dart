import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:sports/Core/Services/app_pref.dart';
import 'package:sports/Core/errors/failuer.dart';
import 'package:sports/Features/Authentication/data/data_source/authentication_data_source.dart';
import 'package:sports/Features/Authentication/data/models/register_parent_request_model.dart';
import 'package:sports/Features/Authentication/data/models/register_student_request_model.dart';

class AuthenticationRepository {
  final AuthenticationDataSource dataSource;
  AuthenticationRepository({required this.dataSource});
  Future<Either<Failuer, String>> login(
      {required String email, required String password}) async {
    Response response =
        await dataSource.login(email: email, password: password);
    log(response.data.toString(), name: 'asldkfjalskdf');
    if (response.statusCode == 200) {
      CacheHelper.setToken(token: response.data['token']);
      CacheHelper.setRole(role: response.data['role']);
      CacheHelper.setUserId(userId: response.data['userId']);
      // CacheHelper.setToken(token: response.data['userId']);
      CacheHelper.login();
      // log(CacheHelper.checkLogin().toString(), name: "lskdjfslkjflskdjlskdjf");
      return right(response.data['role']);
    } else {
      // Logger().t(response.data);
      log(response.data.toString(), name: "Error");
      return left(ServerFailuer(message: response.data['message']));
    }
  }

  Future<Either<Failuer, String>> registerChild({
    required RegisterStudentRequestModel model,
  }) async {
    Response response = await dataSource.registerChild(model: model);
    if (response.statusCode == 200) {
      CacheHelper.setToken(token: response.data['token']);
      CacheHelper.setToken(token: response.data['userId']);
      CacheHelper.login();
      return right(response.data['message']);
    } else {
      return left(ServerFailuer(message: response.data['message']));
    }
  }

  Future<Either<Failuer, String>> registerParent({
    required RegisterParentRequestModel model,
  }) async {
    Response response = await dataSource.registerParent(model: model);
    log(response.statusCode.toString(), name: "lksdjflskdjflsdkfj");
    log(response.data.toString(), name: "lksdjflskdjflsdkfj");
    if (response.statusCode == 200) {
      CacheHelper.setToken(token: response.data['token']);
      CacheHelper.setToken(token: response.data['userId']);
      return right(response.data['message']);
    } else {
      log(response.data.toString());
      return left(ServerFailuer(message: response.data['message'] ?? ""));
    }
  }
}
