import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/resources/color.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Features/Authentication/presentation/screens/child_sign_up_screen.dart';
import 'package:sports/Features/Authentication/presentation/screens/parent_sign_up_screen.dart';
import 'package:toastification/toastification.dart';

class ChosesScreen extends StatefulWidget {
  const ChosesScreen({super.key});

  @override
  State<ChosesScreen> createState() => _ChosesScreenState();
}

class _ChosesScreenState extends State<ChosesScreen> {
  List titel = ["Child", "Parent"];
  int? selectedItem;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              width: double.infinity,
              height: 50,
            ),
            ...List.generate(
              titel.length,
              (index) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedItem = index;
                    });
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    margin: const EdgeInsets.symmetric(vertical: 15),
                    width: MediaQuery.of(context).size.width * 0.4,
                    height: 150,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColor.primaryColor2),
                        color: selectedItem == index
                            ? AppColor.primaryColor2
                            : Colors.transparent),
                    child: Center(
                      child: Text(
                        titel[index],
                        style: TextStyle(
                            fontSize: 25,
                            color: selectedItem == index
                                ? Colors.white
                                : Colors.black),
                      ),
                    ),
                  ),
                );
              },
            ),
            const Spacer(),
            CustomButton(
                onTap: () {
                  if (selectedItem == null) {
                    toastification.show(
                        autoCloseDuration: const Duration(seconds: 3),
                        context: context,
                        description: const Text("Please choose first"),
                        type: ToastificationType.warning);
                  } else {
                    if (selectedItem == 0) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ChildSignUpScreen(),
                        ),
                      );
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ParentSignUpScreen(),
                        ),
                      );
                    }
                  }
                },
                text: "Continue"),
            const Gap(30),
          ],
        ),
      ),
    );
  }
}
