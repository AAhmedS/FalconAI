import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Authentication/data/models/register_student_request_model.dart';
import 'package:sports/Features/Authentication/presentation/cubit/authentication_cubit.dart';

class ChildSignUpScreen extends StatefulWidget {
  const ChildSignUpScreen({super.key});

  @override
  State<ChildSignUpScreen> createState() => _ChildSignUpScreenState();
}

class _ChildSignUpScreenState extends State<ChildSignUpScreen> {
  TextEditingController fullName = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController age = TextEditingController();
  TextEditingController password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: BlocConsumer<AuthenticationCubit, AuthenticationState>(
      listener: (context, state) {
        if (state is FailureAuthenticationState) {
          errorToast(context: context, message: state.message);
        }
        if (state is SuccessRegisterState) {
          successToast(context: context, message: state.message);
        }
      },
      builder: (context, state) {
        if (state is LoadingAuthenticationState) {
          return const LoadingWidget();
        } else {
          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                    minHeight: MediaQuery.of(context).size.height,
                    minWidth: MediaQuery.of(context).size.width),
                child: IntrinsicHeight(
                  child: Column(
                    children: [
                      const Gap(40),
                      const Text(
                        "Sign Up",
                        style: TextStyle(
                            fontSize: 30, fontWeight: FontWeight.bold),
                      ),
                      const Gap(30),
                      const Spacer(),
                      CustomTextField(
                        controller: fullName,
                        hintText: "Full Name",
                      ),
                      const Gap(30),
                      CustomTextField(
                        controller: email,
                        hintText: "Email",
                      ),
                      const Gap(30),
                      CustomTextField(
                        controller: age,
                        hintText: "Age",
                      ),
                      const Gap(30),
                      CustomTextField(
                        controller: password,
                        hintText: "Password",
                      ),
                      const Spacer(),
                      CustomButton(
                          onTap: () {
                            context.read<AuthenticationCubit>().registerChild(
                                    model: RegisterStudentRequestModel(
                                  age: int.parse(age.text),
                                  email: email.text,
                                  fullName: fullName.text,
                                  gender: 1,
                                  password: password.text,
                                ));
                          },
                          text: "Sign Up"),
                      const Gap(40)
                    ],
                  ),
                ),
              ),
            ),
          );
        }
      },
    ));
  }
}
