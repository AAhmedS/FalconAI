import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/resources/images.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Authentication/presentation/cubit/authentication_cubit.dart';
import 'package:sports/Features/Coach/presentation/screens/nav_bar_coach.dart';
import 'package:sports/Features/Parent/presentation/screens/parent_nav_bar.dart';
import 'package:sports/Features/Player/presentation/screens/player_nav_bar.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
          key: formKey,
          child: BlocConsumer<AuthenticationCubit, AuthenticationState>(
            listener: (context, state) {
              if (state is FailureAuthenticationState) {
                errorToast(context: context, message: state.message);
              }
              if (state is SuccessLoginState) {
                if (state.role == "Captain") {
                  context.pushAndRemoveUntil(const NavBarCoach());
                }
                if (state.role == "Player") {
                  context.pushAndRemoveUntil(const PlayerNavBar());
                }
                if (state.role == "Parent") {
                  context.pushAndRemoveUntil(const ParentNavBar());
                }
              }
            },
            builder: (context, state) {
              if (state is LoadingAuthenticationState) {
                return const LoadingWidget();
              } else {
                return Container(
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                    image: AssetImage(AppImages.backgroundLogin),
                    fit: BoxFit.cover,
                  )),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      const Gap(40),
                      
                      Column(
                        children: [
                          Image.asset(AppImages.logo),
                          const Gap(8),
                          const Text(
                            "Sign in to your\nAccount",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 32,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          const Gap(5),
                          const Text(
                            "Enter your email and password to log in ",
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white,
                            ),
                          )
                        ],
                      ),
                      const Gap(30),
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          children: [
                            const Text(
                              "Login",
                              style: TextStyle(
                                fontSize: 32,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Text.rich(TextSpan(children: [
                              TextSpan(
                                  text: "Don’t have an account? ",
                                  style: TextStyle(
                                      fontSize: 12, color: Color(0xff6C7278))),
                              TextSpan(
                                  text: "Sign Up",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Color(0xff456FD3),
                                    fontWeight: FontWeight.bold,
                                  ))
                            ])),
                            const Gap(20),
                            CustomTextField(
                              controller: email,
                              label: "Email",
                              hintText: "Email",
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your email";
                                }
                                return null;
                              },
                            ),
                            const Gap(10),
                            CustomTextField(
                              controller: password,
                              label: "Password",
                              hintText: "Password",
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your password";
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            "Forgot Password ?",
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xff456FD3),
                              fontWeight: FontWeight.w600,
                            ),
                          )
                        ],
                      ),
                      const Gap(10),
                      CustomButton(
                          onTap: () {
                            if (formKey.currentState!.validate()) {
                              context.read<AuthenticationCubit>().login(
                                  email: email.text, password: password.text);
                            }
                          },
                          text: "Login"),
                    ],
                  ),
                );
              }
            },
          )),
    );
  }
}
