import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Authentication/data/models/register_parent_request_model.dart';
import 'package:sports/Features/Authentication/presentation/cubit/authentication_cubit.dart';
import 'package:sports/Features/Parent/presentation/screens/parent_nav_bar.dart';

class ParentSignUpScreen extends StatefulWidget {
  const ParentSignUpScreen({super.key});

  @override
  State<ParentSignUpScreen> createState() => _GuardianSignUpScreenState();
}

class _GuardianSignUpScreenState extends State<ParentSignUpScreen> {
  TextEditingController fullName = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController idNumber = TextEditingController();
  TextEditingController registerNumber = TextEditingController();
  TextEditingController password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: BlocConsumer<AuthenticationCubit, AuthenticationState>(
      listener: (context, state) {
        if (state is FailureAuthenticationState) {
          errorToast(context: context, message: state.message);
        }
        if (state is SuccessRegisterState) {
          context.push(const ParentNavBar());
        }
      },
      builder: (context, state) {
        if (state is LoadingAuthenticationState) {
          return const LoadingWidget();
        }
        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height,
                  minWidth: MediaQuery.of(context).size.width),
              child: IntrinsicHeight(
                child: Column(
                  children: [
                    const Gap(40),
                    const Text(
                      "Sign Up",
                      style:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                    ),
                    const Gap(30),
                    const Spacer(),
                    CustomTextField(
                      controller: fullName,
                      hintText: "Full Name",
                    ),
                    const Gap(30),
                    CustomTextField(
                      controller: phone,
                      hintText: "Phone Number",
                    ),
                    const Gap(30),
                    CustomTextField(
                      controller: email,
                      hintText: "Email",
                    ),
                    const Gap(30),
                    CustomTextField(
                      controller: idNumber,
                      hintText: "ID Number",
                    ),
                    const Gap(30),
                    CustomTextField(
                      controller: registerNumber,
                      hintText: "Registration Number",
                    ),
                    const Gap(30),
                    CustomTextField(
                      controller: password,
                      hintText: "Password",
                    ),
                    const Spacer(),
                    CustomButton(
                      onTap: () {
                        context.read<AuthenticationCubit>().registerParent(
                              model: RegisterParentRequestModel(
                                fullName: fullName.text,
                                email: email.text,
                                gender: 1,
                                iDNumber: idNumber.text,
                                password: password.text,
                                phoneNumber: phone.text,
                                registerNumber: registerNumber.text,
                              ),
                            );
                      },
                      text: "Sign Up",
                    ),
                    const Gap(40)
                  ],
                ),
              ),
            ),
          ),
        );
      },
    ));
  }
}
