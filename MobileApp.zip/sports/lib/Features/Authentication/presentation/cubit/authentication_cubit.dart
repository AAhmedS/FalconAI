import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:sports/Features/Authentication/data/models/register_parent_request_model.dart';
import 'package:sports/Features/Authentication/data/models/register_student_request_model.dart';
import 'package:sports/Features/Authentication/data/repository/authentication_repository.dart';

part 'authentication_state.dart';

class AuthenticationCubit extends Cubit<AuthenticationState> {
  final AuthenticationRepository repository;
  AuthenticationCubit({required this.repository})
      : super(AuthenticationInitial());
  login({required String email, required String password}) async {
    emit(LoadingAuthenticationState());
    var resposne = await repository.login(email: email, password: password);
    resposne.fold(
      (l) {
        emit(FailureAuthenticationState(message: l.message));
      },
      (r) {
        emit(SuccessLoginState(role: r));
      },
    );
  }

  registerParent({required RegisterParentRequestModel model}) async {
    emit(LoadingAuthenticationState());
    var resposne = await repository.registerParent(model: model);
    resposne.fold(
      (l) {
        emit(FailureAuthenticationState(message: l.message));
      },
      (r) {
        emit(SuccessRegisterState(message: r));
      },
    );
  }

  registerChild({required RegisterStudentRequestModel model}) async {
    emit(LoadingAuthenticationState());
    var resposne = await repository.registerChild(model: model);
    resposne.fold(
      (l) {
        emit(FailureAuthenticationState(message: l.message));
      },
      (r) {
        emit(SuccessRegisterState(message: r));
      },
    );
  }
}
