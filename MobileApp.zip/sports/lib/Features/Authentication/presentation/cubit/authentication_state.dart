part of 'authentication_cubit.dart';

@immutable
sealed class AuthenticationState {}

final class AuthenticationInitial extends AuthenticationState {}

class SuccessLoginState extends AuthenticationState {
  final String role;

  SuccessLoginState({required this.role});
}

class FailureAuthenticationState extends AuthenticationState {
  final String message;

  FailureAuthenticationState({required this.message});
}

class SuccessRegisterState extends AuthenticationState {
  final String message;

  SuccessRegisterState({required this.message});
}

class LoadingAuthenticationState extends AuthenticationState {}
