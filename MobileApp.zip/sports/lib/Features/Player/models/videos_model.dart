class VideosModel {
  int? id;
  String? videoPath;
  String? title;
  String? description;
  String? postAt;

  VideosModel({
    this.id,
    this.videoPath,
    this.title,
    this.description,
    this.postAt,
  });

  factory VideosModel.fromJson(Map<String, dynamic> json) => VideosModel(
        id: json['id'] as int?,
        videoPath: json['videoPath'] as String?,
        title: json['title'] as String?,
        description: json['description'] as String?,
        postAt: json['postAt'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'videoPath': videoPath,
        'title': title,
        'description': description,
        'postAt': postAt,
      };
}
