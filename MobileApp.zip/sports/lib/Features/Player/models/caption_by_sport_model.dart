class CaptionBySportModel {
  String? id;
  int? gender;
  String? fullName;
  dynamic photoPath;

  CaptionBySportModel({
    this.id,
    this.gender,
    this.fullName,
    this.photoPath,
  });

  factory CaptionBySportModel.fromJson(Map<String, dynamic> json) {
    return CaptionBySportModel(
      id: json['id'] as String?,
      gender: json['gender'] as int?,
      fullName: json['fullName'] as String?,
      photoPath: json['photoPath'] as dynamic,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'gender': gender,
        'fullName': fullName,
        'photoPath': photoPath,
      };
}
