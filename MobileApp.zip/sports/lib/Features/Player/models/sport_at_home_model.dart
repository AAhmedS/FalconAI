class SportAtHomeModel {
  String? captainId;
  String? gender;
  String? fullName;
  String? captainPhotoPath;
  int? sportId;
  String? title;
  String? description;
  String? sportPhotoPath;
  int? bookingCount;

  SportAtHomeModel({
    this.captainId,
    this.gender,
    this.fullName,
    this.captainPhotoPath,
    this.sportId,
    this.title,
    this.description,
    this.sportPhotoPath,
    this.bookingCount,
  });

  factory SportAtHomeModel.fromJson(Map<String, dynamic> json) {
    return SportAtHomeModel(
      captainId: json['captainId'] as String?,
      gender: json['gender'] as String?,
      fullName: json['fullName'] as String?,
      captainPhotoPath: json['captainPhotoPath'] as String?,
      sportId: json['sportId'] as int?,
      title: json['title'] as String?,
      description: json['description'] as String?,
      sportPhotoPath: json['sportPhotoPath'] as String?,
      bookingCount: json['bookingCount'] as int?,
    );
  }

  Map<String, dynamic> toJson() => {
        'captainId': captainId,
        'gender': gender,
        'fullName': fullName,
        'captainPhotoPath': captainPhotoPath,
        'sportId': sportId,
        'title': title,
        'description': description,
        'sportPhotoPath': sportPhotoPath,
        'bookingCount': bookingCount,
      };
}
