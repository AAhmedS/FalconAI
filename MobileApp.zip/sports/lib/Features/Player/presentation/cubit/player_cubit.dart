import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Coach/models/sport_model.dart';
import 'package:sports/Features/Player/models/caption_by_sport_model.dart';
import 'package:sports/Features/Player/models/news_model.dart';
import 'package:sports/Features/Player/models/sport_at_home_model.dart';
import 'package:sports/Features/Player/models/videos_model.dart';

part 'player_state.dart';

class PlayerCubit extends Cubit<PlayerState> {
  PlayerCubit() : super(PlayerInitial());
}
