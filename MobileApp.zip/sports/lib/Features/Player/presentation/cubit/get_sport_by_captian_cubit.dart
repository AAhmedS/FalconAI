import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetSportByCaptianCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetSportByCaptianCubit({required this.repository}) : super(PlayerInitial());
  get({required String captainId}) async {
    var response = await repository.getSportByCaptian(captainId: captainId);
    response.fold(
      (l) {
        emit(FailurePlayerState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllSports(list: r));
      },
    );
  }
}
