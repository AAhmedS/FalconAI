import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetAllSportAtHomeCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetAllSportAtHomeCubit({required this.repository}) : super(PlayerInitial());
  get() async {
    emit(LoadingPlayerState());
    var response = await repository.getAllSportAtHome();
    response.fold(
      (l) {
        emit(FailurePlayerState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllSportAtHomeState(list: r));
      },
    );
  }
}
