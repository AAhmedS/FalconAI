import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetVideosCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetVideosCubit({required this.repository}) : super(PlayerInitial());
  get() async {
    emit(LoadingPlayerState());
    var resposne = await repository.getVideos();
    resposne.fold(
      (l) {
        emit(FailurePlayerState(message: l.message));
      },
      (r) {
        emit(SuccessGetVideosState(list: r));
      },
    );
  }
}
