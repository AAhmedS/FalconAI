import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetCoachsBySportCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetCoachsBySportCubit({required this.repository}) : super(PlayerInitial());
  get({required int sportId}) async {
    emit(LoadingPlayerState());
    var response = await repository.getCaptionBySport(sportId: sportId);
    response.fold(
      (l) {
        emit(FailurePlayerState(message: l.message));
      },
      (r) {
        emit(SuccessGetCaptionBySportState(list: r));
      },
    );
  }
}
