import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetAllNotActiveBookingPlayerCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetAllNotActiveBookingPlayerCubit({required this.repository})
      : super(PlayerInitial());
  get({required String playerId}) async {
    emit(LoadingPlayerState());
    var response = await repository.getAllNotActiveBookings(playerId: playerId);
    response.fold(
      (l) {
        emit(FailurePlayerState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllNotActiveBookingState(list: r));
      },
    );
  }
}
