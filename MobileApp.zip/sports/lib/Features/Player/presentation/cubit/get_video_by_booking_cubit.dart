import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetVideoByBookingCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetVideoByBookingCubit({required this.repository}) : super(PlayerInitial());
  get() {}
}
