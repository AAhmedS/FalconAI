import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetAllCaptainCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetAllCaptainCubit({required this.repository}) : super(PlayerInitial());
  get() async {
    emit(LoadingPlayerState());
    var response = await repository.getAllCaptain();
    response.fold(
      (l) {
        emit(FailurePlayerState(message: l.message));
      },
      (r) {
        emit(SuccessGetCaptionsState(list: r));
      },
    );
  }
}
