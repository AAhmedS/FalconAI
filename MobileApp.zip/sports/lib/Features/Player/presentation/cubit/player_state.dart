part of 'player_cubit.dart';

@immutable
sealed class PlayerState {}

final class PlayerInitial extends PlayerState {}

class SuccessGetAllSports extends PlayerState {
  final List<SportModel> list;

  SuccessGetAllSports({required this.list});
}

class FailurePlayerState extends PlayerState {
  final String message;

  FailurePlayerState({required this.message});
}

class LoadingPlayerState extends PlayerState {}

class SuccessGetCaptionBySportState extends PlayerState {
  final List<CaptionBySportModel> list;

  SuccessGetCaptionBySportState({required this.list});
}

class SuccessGetCaptionsState extends PlayerState {
  final List<CaptionBySportModel> list;

  SuccessGetCaptionsState({required this.list});
}

class SuccessGetNewsState extends PlayerState {
  final List<NewsModel> list;

  SuccessGetNewsState({required this.list});
}

class SuccessGetVideosState extends PlayerState {
  final List<VideosModel> list;

  SuccessGetVideosState({required this.list});
}

class SuccessGetAllActiveBookingState extends PlayerState {
  final List<BookingModel> list;

  SuccessGetAllActiveBookingState({required this.list});
}

class SuccessGetAllNotActiveBookingState extends PlayerState {
  final List<BookingModel> list;

  SuccessGetAllNotActiveBookingState({required this.list});
}

class SuccessGetAllSportAtHomeState extends PlayerState {
  final List<SportAtHomeModel> list;

  SuccessGetAllSportAtHomeState({required this.list});
}
