import 'dart:developer';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Player/data/repository/player_repository.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class GetSportsCubit extends Cubit<PlayerState> {
  final PlayerRepository repository;
  GetSportsCubit({required this.repository}) : super(PlayerInitial());
  getSports() async {
    log("message");
    emit(LoadingPlayerState());
    var response = await repository.getAllSports();
    response.fold(
      (l) {
        emit(FailurePlayerState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllSports(list: r));
      },
    );
  }
}
