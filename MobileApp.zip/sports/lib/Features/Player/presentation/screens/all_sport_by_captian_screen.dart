import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_sport_by_captian_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';
import 'package:sports/Features/Player/presentation/widgets/sport_card.dart';

class AllSportByCaptianScreen extends StatefulWidget {
  const AllSportByCaptianScreen({super.key, required this.captianId});
  final String captianId;

  @override
  State<AllSportByCaptianScreen> createState() =>
      _AllSportByCaptianScreenState();
}

class _AllSportByCaptianScreenState extends State<AllSportByCaptianScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    context.read<GetSportByCaptianCubit>().get(captainId: widget.captianId);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<GetSportByCaptianCubit, PlayerState>(
          builder: (context, state) {
            if (state is LoadingPlayerState) {
              return const LoadingWidget();
            }
            if (state is SuccessGetAllSports) {
              return SingleChildScrollView(
                child: Column(
                  children: state.list.map(
                    (e) {
                      return GestureDetector(
                          onTap: () {
                            // context.push(AllCoachBySportScreen(sportId: e.id!));
                          },
                          child: SportCard(model: e));
                    },
                  ).toList(),
                ),
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
