import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/image_url.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_videos_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';
import 'package:video_player/video_player.dart';

class VideosScreen extends StatelessWidget {
  const VideosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<GetVideosCubit, PlayerState>(
          builder: (context, state) {
            if (state is LoadingPlayerState) {
              return const LoadingWidget();
            }
            if (state is SuccessGetVideosState) {
              return Container(
                margin: const EdgeInsets.only(top: 20),
                child: SingleChildScrollView(
                  child: Column(
                    children: state.list.map(
                      (e) {
                        return Container(
                          width: double.infinity,
                          margin: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white,
                            // boxShadow: const [
                            //   BoxShadow(color: Colors.black38, blurRadius: 30)
                            // ]
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              VideoWidget(
                                videoUrl: imageUrl(e.videoPath),
                              ),
                              const Gap(15),
                              Text(
                                e.title ?? "",
                                style: const TextStyle(fontSize: 20),
                              ),
                              const Gap(5),
                              Text(
                                e.description ?? "",
                              )
                            ],
                          ),
                        );
                      },
                    ).toList(),
                  ),
                ),
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}

class VideoWidget extends StatefulWidget {
  const VideoWidget({super.key, required this.videoUrl});
  final String videoUrl;
  @override
  State<VideoWidget> createState() => _VideoWidgetState();
}

class _VideoWidgetState extends State<VideoWidget> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl))
      ..initialize().then((_) {
        setState(() {}); // لضمان إعادة بناء الـ widget بعد تهيئة الفيديو
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    log(widget.videoUrl);
    return _controller.value.isInitialized
        ? AspectRatio(
            aspectRatio: _controller.value.aspectRatio,
            child: VideoPlayer(_controller),
          )
        : const Center(child: CircularProgressIndicator());
  }
}
