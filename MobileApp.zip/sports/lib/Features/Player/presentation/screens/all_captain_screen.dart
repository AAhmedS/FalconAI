import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_captain_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';
import 'package:sports/Features/Player/presentation/screens/all_sport_by_captian_screen.dart';
import 'package:sports/Features/Player/presentation/widgets/captian_card.dart';

class AllCaptainScreen extends StatelessWidget {
  const AllCaptainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<GetAllCaptainCubit, PlayerState>(
        builder: (context, state) {
          if (state is LoadingPlayerState) {
            return const LoadingWidget();
          }
          if (state is SuccessGetCaptionsState) {
            return Container(
              margin: const EdgeInsets.only(top: 20),
              child: SingleChildScrollView(
                child: Column(
                  children: state.list.map(
                    (e) {
                      return GestureDetector(
                          onTap: () {
                            context.push(AllSportByCaptianScreen(
                              captianId: e.id!,
                            ));
                          },
                          child: CaptianCard(model: e));
                    },
                  ).toList(),
                ),
              ),
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }
}
