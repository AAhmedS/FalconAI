import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/swap_widget.dart';
import 'package:sports/Features/Coach/presentation/widgets/booking_widget.dart';
import 'package:sports/Features/Coach/presentation/widgets/coach_info_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_active_booking_player_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_not_active_booking_player_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class PlayerBookingScreen extends StatefulWidget {
  const PlayerBookingScreen({super.key, required this.playerId});
  final String playerId;
  @override
  State<PlayerBookingScreen> createState() => _PlayerBookingScreenState();
}

class _PlayerBookingScreenState extends State<PlayerBookingScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    context
        .read<GetAllActiveBookingPlayerCubit>()
        .get(playerId: widget.playerId);
    context
        .read<GetAllNotActiveBookingPlayerCubit>()
        .get(playerId: widget.playerId);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            const Gap(20),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: CoachInfoWidget(),
            ),
            const Gap(20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SwapWidget(
                firstTite: "الحجوزات الغير نشطة",
                secondTitle: "الحجوزات النشطة",
                firstWidget:
                    BlocBuilder<GetAllActiveBookingPlayerCubit, PlayerState>(
                  builder: (context, state) {
                    if (state is LoadingPlayerState) {
                      return const LoadingWidget();
                    }
                    if (state is SuccessGetAllActiveBookingState) {
                      return SingleChildScrollView(
                        child: Column(
                          children: state.list.map(
                            (e) {
                              return BookingWidget(
                                model: e,
                                bookingId: e.bookingId!,
                                playerId: e.playerId!,
                              );
                            },
                          ).toList(),
                        ),
                      );
                    } else {
                      return Container();
                    }
                  },
                ),
                secondWidget:
                    BlocBuilder<GetAllNotActiveBookingPlayerCubit, PlayerState>(
                  builder: (context, state) {
                    if (state is LoadingPlayerState) {
                      return const LoadingWidget();
                    }
                    if (state is SuccessGetAllNotActiveBookingState) {
                      return SingleChildScrollView(
                        child: Column(
                          children: state.list.map(
                            (e) {
                              return BookingWidget(
                                model: e,
                                bookingId: e.bookingId!,
                                playerId: e.playerId ?? "",
                              );
                            },
                          ).toList(),
                        ),
                      );
                    } else {
                      return Container();
                    }
                  },
                ),
              ),
            ),
            const Gap(20),
          ],
        ),
      ),
    );
  }
}
