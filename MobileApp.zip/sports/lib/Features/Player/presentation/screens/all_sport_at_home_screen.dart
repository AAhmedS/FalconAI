import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Coach/presentation/widgets/coach_info_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_all_sport_at_home_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';
import 'package:sports/Features/Player/presentation/screens/sport_detils_screen.dart';

class AllSportAtHomeScreen extends StatelessWidget {
  const AllSportAtHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const Gap(30),
              const CoachInfoWidget(),
              const Gap(40),
              BlocBuilder<GetAllSportAtHomeCubit, PlayerState>(
                builder: (context, state) {
                  if (state is LoadingPlayerState) {
                    return const LoadingWidget();
                  }
                  if (state is SuccessGetAllSportAtHomeState) {
                    return StaggeredGrid.count(
                      mainAxisSpacing: 25,
                      crossAxisSpacing: 25,
                      crossAxisCount: 2,
                      children: state.list.map(
                        (e) {
                          return GestureDetector(
                            onTap: () {
                              context.push(SportDetilsScreen(model: e));
                            },
                            child: Container(
                              width: double.infinity,
                              height: 100,
                              decoration: BoxDecoration(
                                image: const DecorationImage(
                                  image: NetworkImage(
                                    "https://img.freepik.com/free-photo/sports-tools_53876-138077.jpg?ga=GA1.1.472872369.1729164140&semt=ais_hybrid",
                                  ),
                                  fit: BoxFit.cover,
                                ),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10.0),
                                child: Stack(
                                  children: [
                                    // التأثير الزجاجي الداكن يغطي كل الـ Container
                                    Positioned.fill(
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.black.withOpacity(0.4),
                                        ),
                                        child: BackdropFilter(
                                          filter: ImageFilter.blur(
                                              sigmaX: 1.0, sigmaY: 1.0),
                                          child: Container(
                                            color:
                                                Colors.black.withOpacity(0.1),
                                          ),
                                        ),
                                      ),
                                    ),
                                    // النص في المنتصف
                                    Container(
                                      padding: const EdgeInsets.all(10),
                                      alignment: Alignment.bottomLeft,
                                      child: Text(
                                        e.title ?? "",
                                        style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ).toList(),
                    );
                  } else {
                    return Container();
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
