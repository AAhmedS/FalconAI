import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_coachs_by_sport_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';
import 'package:sports/Features/Player/presentation/widgets/captian_card.dart';

class AllCoachBySportScreen extends StatefulWidget {
  const AllCoachBySportScreen({super.key, required this.sportId});
  final int sportId;

  @override
  State<AllCoachBySportScreen> createState() => _AllCoachBySportScreenState();
}

class _AllCoachBySportScreenState extends State<AllCoachBySportScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    context.read<GetCoachsBySportCubit>().get(sportId: widget.sportId);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<GetCoachsBySportCubit, PlayerState>(
          builder: (context, state) {
            if (state is LoadingPlayerState) {
              return const LoadingWidget();
            }
            if (state is SuccessGetCaptionBySportState) {
              return SingleChildScrollView(
                child: Column(
                  children: state.list.map(
                    (e) {
                      return CaptianCard(model: e);
                    },
                  ).toList(),
                ),
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
