import 'package:flutter/material.dart';

class ProfilePlayerScreen extends StatelessWidget {
  const ProfilePlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}