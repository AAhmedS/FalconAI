import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_sports_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';
import 'package:sports/Features/Player/presentation/screens/all_coach_by_sport_screen.dart';
import 'package:sports/Features/Player/presentation/widgets/sport_card.dart';

class SportsScreen extends StatelessWidget {
  const SportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<GetSportsCubit, PlayerState>(
          builder: (context, state) {
            if (state is LoadingPlayerState) {
              return const LoadingWidget();
            }
            if (state is SuccessGetAllSports) {
              return SingleChildScrollView(
                child: Column(
                  children: state.list.map(
                    (e) {
                      return GestureDetector(
                          onTap: () {
                            context.push(AllCoachBySportScreen(sportId: e.id!));
                          },
                          child: SportCard(
                            model: e,
                          ));
                    },
                  ).toList(),
                ),
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
