import 'package:flutter/material.dart';
import 'package:sports/Core/Services/app_pref.dart';
import 'package:sports/Core/resources/images.dart';
import 'package:sports/Features/Coach/presentation/screens/home_screen.dart';
import 'package:sports/Features/Player/presentation/screens/all_sport_at_home_screen.dart';
import 'package:sports/Features/Player/presentation/screens/player_booking_screen.dart';

class PlayerNavBar extends StatefulWidget {
  const PlayerNavBar({super.key});

  @override
  State<PlayerNavBar> createState() => _PlayerNavBarState();
}

class _PlayerNavBarState extends State<PlayerNavBar> {
  List icons = [
    AppImages.home,
    AppImages.bookingIcon,
    AppImages.sportsIcon,
  ];
  List pages = [
    const CoachHomeScreen(),
    // const AllCaptainScreen(),
    PlayerBookingScreen(playerId: CacheHelper.getUserId(),),
    const AllSportAtHomeScreen(),
  ];
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        bottomNavigationBar: Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ...List.generate(
                icons.length,
                (index) {
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedIndex = index;
                      });
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.asset(
                          icons[index],
                          color: selectedIndex == index
                              ? const Color(0xff335199)
                              : Colors.black,
                        )
                      ],
                    ),
                  );
                },
              )
            ],
          ),
        ),
        body: pages[selectedIndex],
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:sports/Core/resources/images.dart';
// import 'package:sports/Features/Coach/presentation/screens/all_activity_screen_.dart';
// import 'package:sports/Features/Coach/presentation/screens/booking_screen.dart';
// import 'package:sports/Features/Coach/presentation/screens/home_screen.dart';

// class NavBarCoach extends StatefulWidget {
//   const NavBarCoach({super.key});

//   @override
//   State<NavBarCoach> createState() => _NavBarCoachState();
// }

// class _NavBarCoachState extends State<NavBarCoach> {
//   List icons = [
//     AppImages.home,
//     AppImages.bookingIcon,
//     AppImages.sportsIcon,
//   ];
//   List pages = [
//     const CoachHomeScreen(),
//     const BookingScreen(),
//     const AllActivityScreen()
//     // AllActivityScreen(),
//   ];
//   int selectedIndex = 0;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         bottomNavigationBar: Container(
//           color: Colors.white,
//           padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               ...List.generate(
//                 icons.length,
//                 (index) {
//                   return GestureDetector(
//                     onTap: () {
//                       setState(() {
//                         selectedIndex = index;
//                       });
//                     },
//                     child: Column(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Image.asset(
//                           icons[index],
//                           color: selectedIndex == index
//                               ? const Color(0xff335199)
//                               : Colors.black,
//                         )
//                       ],
//                     ),
//                   );
//                 },
//               )
//             ],
//           ),
//         ),
//         body: pages[selectedIndex]);
//   }
// }
