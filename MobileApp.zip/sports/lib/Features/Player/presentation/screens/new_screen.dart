import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Player/presentation/cubit/get_news_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';

class NewScreen extends StatelessWidget {
  const NewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<GetNewsCubit, PlayerState>(
          builder: (context, state) {
            if (state is LoadingPlayerState) {
              return const LoadingWidget();
            }
            if (state is SuccessGetNewsState) {
              return Container(
                margin: const EdgeInsets.only(top: 20),
                child: SingleChildScrollView(
                  child: Column(
                    children: state.list.map(
                      (e) {
                        return Container(
                          width: double.infinity,
                          margin: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(color: Colors.black12, blurRadius: 20)
                              ]),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                e.title ?? "",
                                style: const TextStyle(fontSize: 20),
                              ),
                              const Gap(5),
                              const Divider(),
                              const Gap(5),
                              Text(e.description ?? ""),
                              Image.network(
                                  "https://s3-alpha-sig.figma.com/img/84d8/963c/6c4d88618db743feb0cecf106a1f0794?Expires=1730073600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=o1ghU~ItjwHEtxqJSUg08C2TRRfKhnweRsdHYwDDbtfdH3O5y2NvoeJpbCWuEZbB2RIr7qX5mfLqzuhjvNCI4ZZ9iwlEIDgbsRvz-FogFsCSe8yv77Ml1p4jYxWQmlDrR4ZfRhsfzy3UGuHukmXcyJSenPaNZ2rkeVTonNYtUnXQENJ-~LDlrU6Aacd6mohY7~Gddy5FVqk2fEDWbYKsgnQxXcui2Gp1AD0e5Y4UwHZ1e8-o8rBBSkt5ccwWng04mkNWo-DuNJwCtY-sJJhqNqO8iPv~tWtebrxhueAzEO3N0~AztErMn1y74CRfoFFVYyNiQ8GJe8E5MXr7DrM9kA__")
                            ],
                          ),
                        );
                      },
                    ).toList(),
                  ),
                ),
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
