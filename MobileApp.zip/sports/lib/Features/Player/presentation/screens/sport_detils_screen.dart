import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:readmore/readmore.dart';
import 'package:sports/Features/Player/models/sport_at_home_model.dart';

class SportDetilsScreen extends StatelessWidget {
  const SportDetilsScreen({super.key, required this.model});
  final SportAtHomeModel model;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            width: double.infinity,
            height: 200,
            decoration: const BoxDecoration(
              image: DecorationImage(image: NetworkImage("https://img.freepik.com/free-photo/sports-tools_53876-138077.jpg?ga=GA1.1.472872369.1729164140&semt=ais_hybrid"), fit: BoxFit.cover,)
            ),
          ),
          const Gap(20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(model.title??""),
                const ReadMoreText(
                  "model.description??""model.description??""model.description??""model.description??""model.description??""model.description??""model.description??""model.descriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescription??"""
                  ,
                  textAlign: TextAlign.end,
                  style: TextStyle(fontSize: 10),
                ),
                const Gap(30),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(model.fullName??""),
                  Text(model.gender??""),
                ],
              ),
              const Gap(10),
              Container(
                width: 50,
                height: 50,
                decoration: const BoxDecoration(
                  image: DecorationImage(image: NetworkImage("https://img.freepik.com/free-photo/sports-tools_53876-138077.jpg?ga=GA1.1.472872369.1729164140&semt=ais_hybrid"), fit: BoxFit.cover,),
                  shape: BoxShape.circle
                ),
              ),
            ],
          )
              ],
            ),
          ),
          
        ],
      ),
    );
  }
}
