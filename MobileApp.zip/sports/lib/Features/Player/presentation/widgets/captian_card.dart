import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/image_url.dart';
import 'package:sports/Features/Player/models/caption_by_sport_model.dart';

class CaptianCard extends StatelessWidget {
  const CaptianCard({super.key, required this.model});
  final CaptionBySportModel model;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        // color: Colors.white,
        // boxShadow: const [
        //   BoxShadow(color: Colors.black26, blurRadius: 30)
        // ],
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.red,
                image: DecorationImage(
                    image: NetworkImage(imageUrl(model.photoPath)),
                    fit: BoxFit.cover)),
          ),
          const Gap(15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                model.fullName ?? "",
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                model.gender == 1 ? "Male" : "Female",
                style: const TextStyle(
                  color: Colors.grey,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
