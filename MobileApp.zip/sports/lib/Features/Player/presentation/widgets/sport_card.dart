import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/image_url.dart';
import 'package:sports/Features/Coach/models/sport_model.dart';

class SportCard extends StatelessWidget {
  const SportCard({super.key, required this.model});
  final SportModel model;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(15),
      height: 180,
      width: double.infinity,
      // padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        // color: Colors.red,
        // image: DecorationImage(image: NetworkImage("https://img.freepik.com/free-photo/sports-tools_53876-138077.jpg?size=626&ext=jpg"), fit: BoxFit.cover,)
      ),
      child: Stack(
        // crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(
                  image: NetworkImage(imageUrl(model.photoPath)),
                  fit: BoxFit.cover,
                )),
          ),
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                borderRadius: BorderRadius.circular(10)),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            height: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  model.title ?? "",
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const Gap(6),
                Text(
                  model.description ?? "",
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
