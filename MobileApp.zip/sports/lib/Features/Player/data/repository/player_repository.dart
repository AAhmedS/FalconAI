import 'package:dartz/dartz.dart';
import 'package:sports/Core/Services/base_repository.dart';
import 'package:sports/Core/errors/failuer.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Coach/models/sport_model.dart';
import 'package:sports/Features/Player/data/data_source/player_data_source.dart';
import 'package:sports/Features/Player/models/caption_by_sport_model.dart';
import 'package:sports/Features/Player/models/news_model.dart';
import 'package:sports/Features/Player/models/sport_at_home_model.dart';
import 'package:sports/Features/Player/models/videos_model.dart';

class PlayerRepository {
  final PlayerDataSource dataSource;
  final BaseRepository baseRepository;
  PlayerRepository({required this.dataSource, required this.baseRepository});

  Future<Either<Failuer, List<BookingModel>>> getAllActiveBookings({required String playerId}) async {
    var response =
        await baseRepository.repository(dataSource.getAllActiveBookings(playerId: playerId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getAllNotActiveBookings({required String playerId}) async {
    var response =
        await baseRepository.repository(dataSource.getAllNotActiveBookings(playerId: playerId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<ActivityModel>>> getAllActivitiesForBooking(
      {required String bookingId}) async {
    var response = await baseRepository.repository(
        dataSource.getAllActivitiesForBooking(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<ActivityModel> list = (r.data as List)
            .map(
              (e) => ActivityModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getRatePlayer(
      {required int bookingId}) async {
    var response = await baseRepository
        .repository(dataSource.getRatePlayer(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<SportModel>>> getSportPlayer(
      {required int sportId}) async {
    var response = await baseRepository
        .repository(dataSource.getSportPlayer(sportId: sportId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<SportModel> list = (r.data as List)
            .map(
              (e) => SportModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<SportModel>>> getSportByCaptian(
      {required String captainId}) async {
    var response = await baseRepository
        .repository(dataSource.getAllSportByCaptian(captainId: captainId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<SportModel> list = (r.data as List)
            .map(
              (e) => SportModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<SportModel>>> getAllSports() async {
    var response = await baseRepository.repository(dataSource.getAllSports());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<SportModel> list = (r.data as List)
            .map(
              (e) => SportModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getCaptainPlayer(
      {required int captainId}) async {
    var response = await baseRepository
        .repository(dataSource.getCaptainPlayer(captainId: captainId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getAllActivitiesPlayer(
      {required int bookingId}) async {
    var response = await baseRepository
        .repository(dataSource.getAllActivitiesPlayer(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getActivity(
      {required int activityId}) async {
    var response = await baseRepository
        .repository(dataSource.getActivity(activityId: activityId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getProfile(
      {required int activityId}) async {
    var response = await baseRepository.repository(dataSource.getProfile());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getPlayerVideos(
      {required int activityId}) async {
    var response =
        await baseRepository.repository(dataSource.getPlayerVideos());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<CaptionBySportModel>>> getCaptionBySport(
      {required int sportId}) async {
    var response = await baseRepository
        .repository(dataSource.getCaptionBySport(sportId: sportId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<CaptionBySportModel> list = (r.data as List)
            .map(
              (e) => CaptionBySportModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<CaptionBySportModel>>> getAllCaptain() async {
    var response = await baseRepository.repository(dataSource.getAllcaptain());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<CaptionBySportModel> list = (r.data as List)
            .map(
              (e) => CaptionBySportModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<NewsModel>>> getNews() async {
    var response = await baseRepository.repository(dataSource.getNews());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<NewsModel> list = (r.data as List)
            .map(
              (e) => NewsModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<VideosModel>>> getVideos() async {
    var response = await baseRepository.repository(dataSource.getVideos());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<VideosModel> list = (r.data as List)
            .map(
              (e) => VideosModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }
  Future<Either<Failuer, List<SportAtHomeModel>>> getAllSportAtHome() async {
    var response = await baseRepository.repository(dataSource.getAllSportAtHome());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<SportAtHomeModel> list = (r.data as List)
            .map(
              (e) => SportAtHomeModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }
}
