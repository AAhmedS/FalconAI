import 'package:sports/Core/Services/api_client_helper.dart';
import 'package:sports/Core/Services/app_pref.dart';
import 'package:sports/Core/resources/endpoints.dart';

class PlayerDataSource {
  final ApiClientHelper api;
  PlayerDataSource({required this.api});

  getAllNotActiveBookings({required String playerId}) {
    return api.get(
        url: Endpoints.getAllNotActiveBookingsForPlayer,
        queryParameters: {"PlayerId": playerId});
  }

  getAllActiveBookings({required String playerId}) {
    return api.get(
        url: Endpoints.getAllActiveBookingsForPlayer,
        queryParameters: {"PlayerId": playerId});
  }

  getRatePlayer({required int bookingId}) {
    return api.get(
        url: Endpoints.getRatePlayer,
        queryParameters: {"BookingId": bookingId});
  }

  getSportPlayer({required int sportId}) {
    return api.get(
        url: Endpoints.getSportPlayer, queryParameters: {"SportId": sportId});
  }

  getAllSports() {
    return api.get(
        url: Endpoints.getAllSports,
        queryParameters: {"PlayerId": CacheHelper.getUserId()});
  }

  getCaptainPlayer({required int captainId}) {
    return api.get(
        url: Endpoints.getCaptainPlayer,
        queryParameters: {"CaptainId": captainId});
  }

  getAllActivitiesPlayer({required int bookingId}) {
    return api.get(
        url: Endpoints.getAllActivitiesPlayer,
        queryParameters: {"BookingId": bookingId});
  }

  getActivity({required int activityId}) {
    return api.get(url: Endpoints.getAllActivitiesPlayer);
  }

  getProfile() {
    return api.get(url: Endpoints.getAllActivitiesPlayer);
  }

  getPlayerVideos() {
    return api.get(url: Endpoints.getPlayerVideos);
  }

  getAllcaptain() {
    return api.get(url: Endpoints.getAllCaptains);
  }

  getAllSportByCaptian({required String captainId}) {
    return api.get(
        url: Endpoints.getAllSportsByCaptain,
        queryParameters: {"CaptainId": captainId});
  }

  getAllActivitiesForBooking({required String bookingId}) {
    return api.get(
        url: Endpoints.getAllActivitiesForBooking,
        queryParameters: {"BookingId": bookingId});
  }

  getCaptionBySport({required int sportId}) {
    return api.get(
        url: Endpoints.getAllCaptainsBySport,
        queryParameters: {"SportId": sportId});
  }

  getNews() {
    return api.get(url: Endpoints.getAllNews);
  }

  getVideos() {
    return api.get(url: Endpoints.getAllVideos);
  }

  getAllSportAtHome() {
    return api.get(url: Endpoints.getAllSportsAtHome);
  }
}
