class RatingModel {
  String? fitness;
  String? speed;
  String? strength;
  String? skill;
  int? bookingId;
  int? id;

  RatingModel(
      {this.fitness,
      this.speed,
      this.strength,
      this.skill,
      this.bookingId,
      this.id});

  factory RatingModel.fromJson(Map<String, dynamic> json) => RatingModel(
        fitness: json['fitness'] as String?,
        speed: json['speed'] as String?,
        strength: json['strength'] as String?,
        skill: json['skill'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'fitness': fitness,
        'speed': speed,
        'strength': strength,
        'skill': skill,
      };

  Map<String, dynamic> create() => {
        'fitness': fitness,
        'speed': speed,
        'strength': strength,
        'skill': skill,
      };
  Map<String, dynamic> update() => {
        'fitness': fitness,
        'speed': speed,
        'strength': strength,
        'skill': skill,
      };
}
