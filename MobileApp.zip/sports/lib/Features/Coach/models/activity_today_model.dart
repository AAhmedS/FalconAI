class ActivityTodayModel {
  int? activityId;
  String? title;
  String? description;
  String? attendance;
  bool? isPassFirstTest;
  bool? isPassSecondTest;
  int? playerAge;
  String? playerName;
  int? sportId;
  String? sportTitle;

  ActivityTodayModel({
    this.activityId,
    this.title,
    this.description,
    this.attendance,
    this.isPassFirstTest,
    this.isPassSecondTest,
    this.playerAge,
    this.playerName,
    this.sportId,
    this.sportTitle,
  });

  factory ActivityTodayModel.fromJson(Map<String, dynamic> json) {
    return ActivityTodayModel(
      activityId: json['activityId'] as int?,
      title: json['title'] as String?,
      description: json['description'] as String?,
      attendance: json['attendance'] as String?,
      isPassFirstTest: json['isPassFirstTest'] as bool?,
      isPassSecondTest: json['isPassSecondTest'] as bool?,
      playerAge: json['playerAge'] as int?,
      playerName: json['playerName'] as String?,
      sportId: json['sportId'] as int?,
      sportTitle: json['sportTitle'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'activityId': activityId,
        'title': title,
        'description': description,
        'attendance': attendance,
        'isPassFirstTest': isPassFirstTest,
        'isPassSecondTest': isPassSecondTest,
        'playerAge': playerAge,
        'playerName': playerName,
        'sportId': sportId,
        'sportTitle': sportTitle,
      };
}
