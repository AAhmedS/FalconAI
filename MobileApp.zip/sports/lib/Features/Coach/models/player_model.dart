class PlayerModel {
  int? age;
  String? gender;
  String? fullName;
  int? weight;
  int? height;
  String? direction;
  dynamic photoPath;

  PlayerModel({
    this.age,
    this.gender,
    this.fullName,
    this.weight,
    this.height,
    this.direction,
    this.photoPath,
  });

  factory PlayerModel.fromJson(Map<String, dynamic> json) => PlayerModel(
        age: json['age'] as int?,
        gender: json['gender'] as String?,
        fullName: json['fullName'] as String?,
        weight: json['weight'] as int?,
        height: json['height'] as int?,
        direction: json['direction'] as String?,
        photoPath: json['photoPath'] as dynamic,
      );

  Map<String, dynamic> toJson() => {
        'age': age,
        'gender': gender,
        'fullName': fullName,
        'weight': weight,
        'height': height,
        'direction': direction,
        'photoPath': photoPath,
      };
}
