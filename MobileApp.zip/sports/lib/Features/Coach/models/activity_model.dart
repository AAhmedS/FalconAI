class ActivityModel {
  int? id;
  String? title;
  String? description;
  DateTime? attendanceDate;
  String? attendance;
  int? bookingId;

  ActivityModel(
      {this.title,
      this.description,
      this.attendanceDate,
      this.bookingId,
      this.attendance,
      this.id});

  factory ActivityModel.fromJson(Map<String, dynamic> json) => ActivityModel(
        title: json['title'] as String?,
        description: json['description'] as String?,
        attendanceDate: json['attendanceDate'] == null
            ? null
            : DateTime.parse(json['attendanceDate'] as String),
        bookingId: json['bookingId'] as int?,
        id: json['id'] as int?,
        attendance: json['attendance'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'title': title,
        'description': description,
        'attendanceDate': attendanceDate?.toIso8601String(),
        'bookingId': bookingId,
        'id': id
      };
  Map<String, dynamic> create() => {
        "title": title,
        "description": description,
        "attendanceDate": attendanceDate,
        "bookingId": bookingId
      };
  Map<String, dynamic> update() => {
        "title": title,
        "description": description,
        "attendanceDate": attendanceDate
      };
}
