class BookingModel {
  int? bookingId;
  int? sportId;
  String? playerId;
  int? presentSessions;
  int? absentSessions;
  bool? isActive;
  int? numberOfSessions;
  String? startAt;
  String? endAt;

  BookingModel({
    this.bookingId,
    this.sportId,
    this.playerId,
    this.presentSessions,
    this.absentSessions,
    this.isActive,
    this.numberOfSessions,
    this.startAt,
    this.endAt,
  });

  factory BookingModel.fromJson(Map<String, dynamic> json) => BookingModel(
        bookingId: json['bookingId'] as int?,
        sportId: json['sportId'] as int?,
        playerId: json['playerId'] as String?,
        presentSessions: json['presentSessions'] as int?,
        absentSessions: json['absentSessions'] as int?,
        isActive: json['isActive'] as bool?,
        numberOfSessions: json['numberOfSessions'] as int?,
        startAt: json['startAt'] as String?,
        endAt: json['endAt'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'bookingId': bookingId,
        'sportId': sportId,
        'playerId': playerId,
        'presentSessions': presentSessions,
        'absentSessions': absentSessions,
        'isActive': isActive,
        'numberOfSessions': numberOfSessions,
        'startAt': startAt,
        'endAt': endAt,
      };
}
