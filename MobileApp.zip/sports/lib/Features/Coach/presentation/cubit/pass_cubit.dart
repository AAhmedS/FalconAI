import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class PassCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  PassCubit({required this.repository}) : super(CoachInitial());
  passFirstTest({required int bookingId}) async {
    var response = await repository.passFirstTest(bookingId: bookingId);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessPassFirstTestState());
      },
    );
  }

  passSecondTest({required int bookingId}) async {
    var response = await repository.passSecondTest(bookingId: bookingId);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessPassSecondTestState());
      },
    );
  }
}
