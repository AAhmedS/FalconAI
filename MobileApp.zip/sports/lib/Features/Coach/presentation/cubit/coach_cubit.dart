import 'package:bloc/bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class CoachCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  CoachCubit({required this.repository}) : super(CoachInitial());
}
