import 'dart:io';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class VideoPlayerCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  VideoPlayerCubit({required this.repository}) : super(CoachInitial());
  uploadVideo(
      {required String playerId,
      required String description,
      required File video}) async {
    emit(LoadingCoachState());
    var response = await repository.addVideoToPlayer(
        playerId: playerId, description: description, video: video);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessAddVideoToPlayerState());
      },
    );
  }
}
