import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class ActivityCoashCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  ActivityCoashCubit({required this.repository}) : super(CoachInitial());
  getAllActivities({required int bookingId}) async {
    var response = await repository.getAllActivities(bookingId: bookingId);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllActivitiesState(list: r));
      },
    );
  }

  getActivity({required int activityId}) async {
    var response = await repository.getActivity(activityId: activityId);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessGetActivityState());
      },
    );
  }

  addActivity({required ActivityModel model}) async {
    var response = await repository.addActivity(model: model);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessAddActivityState());
      },
    );
  }

  deleteActivity({required int activityId}) async {
    var response = await repository.deleteActivity(activityId: activityId);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessDeleteActivityState());
      },
    );
  }

  updateActivity({required ActivityModel model}) async {
    var response = await repository.updateActivity(model: model);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessUpdateActivityState());
      },
    );
  }
}
