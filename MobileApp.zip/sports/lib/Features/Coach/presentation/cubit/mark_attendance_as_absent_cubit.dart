import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class MarkAttendanceAsAbsentCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  MarkAttendanceAsAbsentCubit({required this.repository})
      : super(CoachInitial());
  make() async {
    var response = await repository.markAttendanceAsAbsent(activityId: 1);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessMarkAttendanceAsAbsentState());
      },
    );
  }
}
