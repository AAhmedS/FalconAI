import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class GetAllActivityCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  GetAllActivityCubit({required this.repository}) : super(CoachInitial());
  getAllActivities({required int bookingId}) async {
    emit(LoadingCoachState());
    var response = await repository.getAllActivities(bookingId: bookingId);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllActivitiesState(list: r));
      },
    );
  }
}
