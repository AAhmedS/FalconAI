import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/models/rating_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class RatePlayerCoachCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  RatePlayerCoachCubit({required this.repository}) : super(CoachInitial());
  add({required RatingModel model}) async {
    var response = await repository.addRatePlayer(model: model);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessAddRatePlayerState());
      },
    );
  }
}
