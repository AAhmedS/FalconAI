import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class GetAllActiveBookingCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  GetAllActiveBookingCubit({required this.repository}) : super(CoachInitial());
  getAllBooking() async {
    emit(LoadingCoachState());
    var response = await repository.getAllActiveBookings();
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllActiveBookingsState(list: r));
      },
    );
  }
}
