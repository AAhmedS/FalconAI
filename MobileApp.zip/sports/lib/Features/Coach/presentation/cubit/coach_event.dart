// part of 'coach_bloc.dart';

// @immutable
// sealed class CoachEvent {}

// class GetAllBookingsEvent extends CoachEvent {}

// class GetAllActivitiesEvent extends CoachEvent {
//   final int bookingId;

//   GetAllActivitiesEvent({required this.bookingId});
// }

// class GetActivityEvent extends CoachEvent {
//   final int activityId;

//   GetActivityEvent({required this.activityId});
// }

// class AddActivityEvent extends CoachEvent {
//   final ActivityModel model;

//   AddActivityEvent({required this.model});
// }

// class UpdateActivityEvent extends CoachEvent {
//   final ActivityModel model;

//   UpdateActivityEvent({required this.model});
// }

// class DeleteActivityEvent extends CoachEvent {
//   final int activityId;

//   DeleteActivityEvent({required this.activityId});
// }
// class MarkAttendanceAsPresentEvent extends CoachEvent {
//   final int activityId;

//   MarkAttendanceAsPresentEvent({required this.activityId});
// }
// class MarkAttendanceAsAbsentEvent extends CoachEvent {
//   final int activityId;

//   MarkAttendanceAsAbsentEvent({required this.activityId});
// }
// class GetRatePlayerEvent extends CoachEvent {
//   final int bookingId;

//   GetRatePlayerEvent({required this.bookingId});
// }
// class AddRatePlayerEvent extends CoachEvent {
//   final RatingModel model;

//   AddRatePlayerEvent({required this.model});
// }

// class UpdateRatePlayerEvent extends CoachEvent {
//   final RatingModel model;

//   UpdateRatePlayerEvent({required this.model});
// }

// class GetPlayerVideosEvent extends CoachEvent {
//   final int playerId;

//   GetPlayerVideosEvent({required this.playerId});
// }

// class AddVideoToPlayerEvent extends CoachEvent {
//   final String playerId;
//   final String description;

//   AddVideoToPlayerEvent({required this.playerId, required this.description});
// }

// class UpdateVideoPlayerEvent extends CoachEvent {
//   final String playerId;
//   final String description;

//   UpdateVideoPlayerEvent({required this.playerId, required this.description});
// }

// class DeleteVideoPlayerEvent extends CoachEvent {
//   final int videoId;

//   DeleteVideoPlayerEvent({required this.videoId});
// }

// class GetAllSportsForCaptainEvent extends CoachEvent {}

// class GetSportEvent extends CoachEvent {
//   final int sportId;

//   GetSportEvent({required this.sportId});
// }

// class GetPlayerEvent extends CoachEvent {
//   final int playerId;

//   GetPlayerEvent({required this.playerId});
// }
