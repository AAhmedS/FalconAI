import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class SportCoachCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  SportCoachCubit({required this.repository}) : super(CoachInitial());
  getSport({required int sportId}) async {
    emit(LoadingCoachState());
    var response = await repository.getSport(sportId: sportId);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessGetSportState(model: r));
      },
    );
  }
}
