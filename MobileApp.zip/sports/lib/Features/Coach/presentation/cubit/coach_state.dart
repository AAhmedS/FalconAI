// part of 'coach_cubit.dart';

// @immutable
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/models/activity_today_model.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Coach/models/player_model.dart';
import 'package:sports/Features/Coach/models/sport_model.dart';

sealed class CoachState {}

final class CoachInitial extends CoachState {}

class FailureCoachState extends CoachState {
  final String message;

  FailureCoachState({required this.message});
}

class LoadingCoachState extends CoachState {}

class SuccessGetAllNotActiveBookingsState extends CoachState {
  final List<BookingModel> list;

  SuccessGetAllNotActiveBookingsState({required this.list});
}

class SuccessGetAllActiveBookingsState extends CoachState {
  final List<BookingModel> list;

  SuccessGetAllActiveBookingsState({required this.list});
}

class SuccessGetAllActivitiesState extends CoachState {
  final List<ActivityModel> list;

  SuccessGetAllActivitiesState({required this.list});
}

class SuccessGetActivityState extends CoachState {}

class SuccessAddActivityState extends CoachState {}

class SuccessUpdateActivityState extends CoachState {}

class SuccessDeleteActivityState extends CoachState {}

class SuccessMarkAttendanceAsPresentState extends CoachState {}

class SuccessMarkAttendanceAsAbsentState extends CoachState {}

class SuccessGetRatePlayerState extends CoachState {}

class SuccessAddRatePlayerState extends CoachState {}

class SuccessUpdateRatePlayerState extends CoachState {}

class SuccessGetPlayerVideosState extends CoachState {}

class SuccessAddVideoToPlayerState extends CoachState {}

class SuccessUpdateVideoPlayerState extends CoachState {}

class SuccessDeleteVideoPlayerState extends CoachState {}

class SuccessGetAllSportsForCaptainState extends CoachState {}

class SuccessGetSportState extends CoachState {
  final SportModel model;

  SuccessGetSportState({required this.model});
}

class SuccessGetPlayerState extends CoachState {
  final PlayerModel model;

  SuccessGetPlayerState({required this.model});
}

class SuccessPassFirstTestState extends CoachState {}

class SuccessPassSecondTestState extends CoachState {}

class SuccessGetAllActivityTodayState extends CoachState {
  final List<ActivityTodayModel> list;

  SuccessGetAllActivityTodayState({required this.list});
}

class SuccessAbsentActivitesState extends CoachState{}
class SuccessPresentActivitiesState extends CoachState{}