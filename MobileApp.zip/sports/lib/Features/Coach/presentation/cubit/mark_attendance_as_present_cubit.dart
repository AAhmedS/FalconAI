import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class MarkAttendanceAsPresentCubit extends Cubit<CoachState> {
  MarkAttendanceAsPresentCubit() : super(CoachInitial());
}