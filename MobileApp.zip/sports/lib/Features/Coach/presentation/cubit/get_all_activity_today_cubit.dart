import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class GetAllActivityTodayCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  GetAllActivityTodayCubit({required this.repository}) : super(CoachInitial());
  get({
    bool? isPassFirstTest,
    bool? isPassSecondTest,
    int? minAge,
    int? maxAge,
  }) async {
    var response = await repository.getAllActivitiesForToday(
        isPassFirstTest: isPassFirstTest,
        isPassSecondTest: isPassSecondTest,
        minAge: minAge,
        maxAge: maxAge);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessGetAllActivityTodayState(list: r));
      },
    );
  }
}
