import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/models/activity_today_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class PresentActivitiesCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  List<int> activityIds = [];
  List<int> deleteActivityIds = [];
  PresentActivitiesCubit({required this.repository}) : super(CoachInitial());
  presentActivities({required List<ActivityTodayModel> list}) async {
    deleteActivityIds.clear();
    for (var activity in list) {
      if (!activityIds.contains(activity.activityId)) {
        deleteActivityIds.add(activity.activityId!);
      }
    }
    if (activityIds.isNotEmpty) {
      var response =
          await repository.presentActivities(activityIds: activityIds);
      response.fold(
        (l) {
          emit(FailureCoachState(message: l.message));
        },
        (r) {
          emit(SuccessPresentActivitiesState());
        },
      );
    }
    if (deleteActivityIds.isNotEmpty) {
      var response = await repository.absentActivites(activityIds: activityIds);
      response.fold(
        (l) {
          emit(FailureCoachState(message: l.message));
        },
        (r) {
          emit(SuccessAbsentActivitesState());
        },
      );
    }
  }

  add({required int id}) {
    activityIds.add(id);
  }

  remove({required int id}) {
    activityIds.remove(id);
  }
}
