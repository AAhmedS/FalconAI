import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sports/Features/Coach/data/repository/coach_repository.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class AbsentActivitesCubit extends Cubit<CoachState> {
  final CoachRepository repository;
  List<int> activityIds = [];
  AbsentActivitesCubit({required this.repository}) : super(CoachInitial());
  absent() async {
    var response = await repository.absentActivites(activityIds: activityIds);
    response.fold(
      (l) {
        emit(FailureCoachState(message: l.message));
      },
      (r) {
        emit(SuccessAbsentActivitesState());
      },
    );
  }

  pickList({required int id}) {
    activityIds.add(id);
  }
}
