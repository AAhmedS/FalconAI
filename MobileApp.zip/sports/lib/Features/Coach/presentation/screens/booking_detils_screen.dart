import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Coach/presentation/screens/all_activity_screen.dart';
import 'package:sports/Features/Coach/presentation/screens/player_screen.dart';
import 'package:sports/Features/Coach/presentation/screens/sport_screen.dart';

class BookingDetilsScreen extends StatelessWidget {
  const BookingDetilsScreen({super.key, required this.model});
  final BookingModel model;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const Gap(50),
          Flexible(
            child: GestureDetector(
              onTap: () {
                context.push(SportScreen(sportId: model.sportId!));
              },
              child: Container(
                height: 200,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    boxShadow: const [
                      BoxShadow(color: Colors.black54, blurRadius: 20)
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20)),
                child: const Center(
                  child: Text(
                    "Sport",
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ),
            ),
          ),
          const Gap(50),
          Flexible(
            child: GestureDetector(
              onTap: () {
                context.push(PlayerScreen(
                  playerId: model.playerId!,
                  booknigId: model.bookingId!,
                ));
              },
              child: Container(
                height: 200,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    boxShadow: const [
                      BoxShadow(color: Colors.black54, blurRadius: 20)
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20)),
                child: const Center(
                  child: Text(
                    "Player",
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ),
            ),
          ),
          const Gap(50),
          Flexible(
            child: GestureDetector(
              onTap: () {
                context.push(AllActivityScreen(
                  bookingId: model.bookingId!,
                ));
              },
              child: Container(
                height: 200,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    boxShadow: const [
                      BoxShadow(color: Colors.black54, blurRadius: 20)
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20)),
                child: const Center(
                  child: Text(
                    "Activity",
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ),
            ),
          ),
          const Gap(50),
        ],
      ),
    );
  }
}
