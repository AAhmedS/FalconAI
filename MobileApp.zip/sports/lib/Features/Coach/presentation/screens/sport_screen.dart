import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/image_url.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/sport_coach_cubit.dart';

class SportScreen extends StatefulWidget {
  const SportScreen({super.key, required this.sportId});
  final int sportId;
  @override
  State<SportScreen> createState() => _SportScreenState();
}

class _SportScreenState extends State<SportScreen> {
  @override
  void initState() {
    super.initState();
    context.read<SportCoachCubit>().getSport(sportId: widget.sportId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<SportCoachCubit, CoachState>(
        builder: (context, state) {
          if (state is LoadingCoachState) {
            return const LoadingWidget();
          }
          if (state is SuccessGetSportState) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Gap(40),
                const SizedBox(
                  width: double.infinity,
                ),
                Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red,
                      image: DecorationImage(
                          image:
                              NetworkImage(imageUrl(state.model.photoPath)))),
                ),
                const Gap(15),
                Text(
                  state.model.title ?? "",
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w600),
                ),
                Text(
                  state.model.description ?? "",
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w400),
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }
}
