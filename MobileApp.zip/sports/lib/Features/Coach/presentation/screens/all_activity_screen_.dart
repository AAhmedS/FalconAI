import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Coach/models/activity_today_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/activity_coash_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_activity_today_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/present_activities_cubit.dart';
import 'package:sports/Features/Coach/presentation/widgets/activity_today_card.dart';
import 'package:sports/Features/Coach/presentation/widgets/coach_info_widget.dart';

class AllActivityScreen extends StatelessWidget {
  AllActivityScreen({super.key});
  List<ActivityTodayModel> list = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 20),
        child: Column(
          children: [
            const CoachInfoWidget(),
            const Gap(30),
            BlocConsumer<ActivityCoashCubit, CoachState>(
              listener: (context, state) {
                if (state is SuccessAddActivityState) {
                  successToast(
                      context: context, message: "Success Add Activity");
                  context.read<GetAllActivityTodayCubit>().get();
                }
                if (state is SuccessDeleteActivityState) {
                  successToast(
                      context: context,
                      message: "Success Delete Activity");
                  context.read<GetAllActivityTodayCubit>().get();
                }
              },
              builder: (context, state) {
                return BlocBuilder<GetAllActivityTodayCubit, CoachState>(
                  builder: (context, state) {
                    if (state is LoadingCoachState) {
                      return const LoadingWidget();
                    }
                    if (state is SuccessGetAllActivityTodayState) {
                      return Expanded(
                        child: Stack(
                          children: [
                            SingleChildScrollView(
                              child: Column(
                                children: state.list.map(
                                  (e) {
                                    return ActivityTodayCard(model: e);
                                  },
                                ).toList(),
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: CustomButton(
                                text: "Done",
                                onTap: () {
                                  context.read<PresentActivitiesCubit>().presentActivities(list: state.list);
                                },
                              ),
                            )
                          ],
                        ),
                      );
                    } else {
                      return Container();
                    }
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
