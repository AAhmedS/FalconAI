import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';

class StudentScreen extends StatelessWidget {
  const StudentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Gap(30),
                Container(
                  width: 100,
                  height: 100,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.red,
                  ),
                ),
                const Gap(10),
                const Text(
                  "zyad mohamed",
                  style: TextStyle(fontSize: 15),
                ),
                const Gap(10),
                const Text(
                  "ولي الامر:   محمد",
                  style: TextStyle(fontSize: 15),
                ),
                const Gap(40),
                CustomTextField(
                    hintText: "السرعه", controller: TextEditingController()),
                const Gap(15),
                CustomTextField(
                    hintText: "الياقة البدنية",
                    controller: TextEditingController()),
                const Gap(15),
                CustomTextField(
                    hintText: "المهاره", controller: TextEditingController()),
                const Gap(15),
                CustomTextField(
                    hintText: "القوه", controller: TextEditingController()),
                const Gap(150),
                const CustomButton(text: "حفظ"),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
