import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sports/Core/function/image_url.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/resources/color.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Coach/models/rating_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/player_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/rate_player_coach_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/video_player_cubit.dart';
import 'package:video_player/video_player.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen(
      {super.key, required this.playerId, required this.booknigId});
  final String playerId;
  final int booknigId;
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late VideoPlayerController videoPlayerController;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    context.read<PlayerCoachCubit>().getPlayer(playerId: widget.playerId);
  }

  TextEditingController fitness = TextEditingController();
  TextEditingController skill = TextEditingController();
  TextEditingController strength = TextEditingController();
  TextEditingController speed = TextEditingController();
  TextEditingController description = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey();
  GlobalKey<FormState> formKeyVideo = GlobalKey();
  File? video;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: Colors.white,
          body: BlocBuilder<PlayerCoachCubit, CoachState>(
            builder: (context, state) {
              if (state is LoadingCoachState) {
                return const LoadingWidget();
              }
              if (state is SuccessGetPlayerState) {
                return BlocListener<RatePlayerCoachCubit, CoachState>(
                  listener: (context, state) {
                    if (state is SuccessAddRatePlayerState) {
                      context.pop();
                      successToast(
                          context: context, message: "Success Add Rate Player");
                    }
                    if (state is FailureCoachState) {
                      context.pop();
                      errorToast(context: context, message: state.message);
                    }
                  },
                  child: Column(
                    children: [
                      const Gap(30),
                      const SizedBox(
                        width: double.infinity,
                      ),
                      Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.red,
                            image: DecorationImage(
                                image: NetworkImage(
                                    imageUrl(state.model.photoPath)))),
                      ),
                      const Gap(20),
                      Text(
                        "${state.model.fullName}",
                        style: const TextStyle(fontSize: 17),
                      ),
                      const Gap(30),
                      Text("Age: ${state.model.age}"),
                      const Gap(10),
                      Text("Gender: ${state.model.gender}"),
                      const Gap(10),
                      Text("Weight: ${state.model.gender}"),
                      const Gap(10),
                      Text("Height: ${state.model.gender}"),
                      const Gap(10),
                      Text("Direction: ${state.model.gender}"),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: CustomButton(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (context) {
                                  return AlertDialog(content: StatefulBuilder(
                                    builder: (context, setStatee) {
                                      return BlocConsumer<VideoPlayerCubit,
                                          CoachState>(
                                        listener: (context, state) {
                                          if (state
                                              is SuccessAddVideoToPlayerState) {
                                            context.pop();
                                            successToast(
                                                context: context,
                                                message: "Success Add Video");
                                          }
                                          if (state is FailureCoachState) {
                                            errorToast(
                                                context: context,
                                                message: state.message);
                                          }
                                        },
                                        builder: (context, state) {
                                          if (state is LoadingCoachState) {
                                            return const SizedBox(
                                              height: 150,
                                              child: Center(
                                                child:
                                                    CircularProgressIndicator(
                                                  color: AppColor.primaryColor1,
                                                ),
                                              ),
                                            );
                                          }
                                          return Form(
                                            key: formKeyVideo,
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                    width: double.infinity,
                                                    height: 200,
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(15),
                                                        border: Border.all()),
                                                    child: video != null
                                                        ? videoPlayerController
                                                                .value
                                                                .isInitialized
                                                            ? AspectRatio(
                                                                aspectRatio:
                                                                    videoPlayerController
                                                                        .value
                                                                        .aspectRatio,
                                                                child: VideoPlayer(
                                                                    videoPlayerController),
                                                              )
                                                            : null
                                                        : null),
                                                const Gap(30),
                                                CustomTextField(
                                                  hintText: "Description",
                                                  controller: description,
                                                  validator: (value) {
                                                    if (value == null ||
                                                        value.isEmpty) {
                                                      return "This field is required.";
                                                    }
                                                    return null;
                                                  },
                                                ),
                                                const Gap(30),
                                                CustomButton(
                                                  onTap: () async {
                                                    if (video == null) {
                                                      var picekdVideo =
                                                          await ImagePicker()
                                                              .pickVideo(
                                                                  source: ImageSource
                                                                      .gallery);
                                                      if (picekdVideo != null) {
                                                        setStatee(() {
                                                          video = File(
                                                              picekdVideo.path);
                                                          videoPlayerController =
                                                              VideoPlayerController
                                                                  .file(video!)
                                                                ..initialize()
                                                                    .then(
                                                                  (value) {
                                                                    setStatee(
                                                                        () {});
                                                                  },
                                                                );
                                                        });
                                                      }
                                                    } else {
                                                      if (formKeyVideo
                                                              .currentState
                                                              ?.validate() ==
                                                          true) {
                                                        context
                                                            .read<
                                                                VideoPlayerCubit>()
                                                            .uploadVideo(
                                                                description:
                                                                    description
                                                                        .text,
                                                                video: video!,
                                                                playerId: widget
                                                                    .playerId);
                                                      }
                                                    }
                                                  },
                                                  text: video == null
                                                      ? "Clik"
                                                      : "Upload",
                                                )
                                              ],
                                            ),
                                          );
                                        },
                                      );
                                    },
                                  ));
                                },
                              );
                            },
                            text: "Add Video"),
                      ),
                      const Gap(15),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: CustomButton(
                            onTap: () {
                              showModalBottomSheet(
                                isScrollControlled: true,
                                context: context,
                                builder: (context) {
                                  return Container(
                                    width: double.infinity,
                                    padding: const EdgeInsets.all(20),
                                    height: MediaQuery.of(context).size.height *
                                        0.6,
                                    child: Form(
                                      key: formKey,
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          CustomTextField(
                                            hintText: "Fitness",
                                            controller: fitness,
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return "This field is required.";
                                              }
                                              return null;
                                            },
                                          ),
                                          const Gap(20),
                                          CustomTextField(
                                            hintText: "Speed",
                                            controller: speed,
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return "This field is required.";
                                              }
                                              return null;
                                            },
                                          ),
                                          const Gap(20),
                                          CustomTextField(
                                            hintText: "Strength",
                                            controller: strength,
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return "This field is required.";
                                              }
                                              return null;
                                            },
                                          ),
                                          const Gap(20),
                                          CustomTextField(
                                            hintText: "Skill",
                                            controller: skill,
                                            validator: (value) {
                                              if (value == null ||
                                                  value.isEmpty) {
                                                return "This field is required.";
                                              }
                                              return null;
                                            },
                                          ),
                                          const Spacer(),
                                          CustomButton(
                                            onTap: () {
                                              if (formKey.currentState
                                                      ?.validate() ==
                                                  true) {
                                                context
                                                    .read<
                                                        RatePlayerCoachCubit>()
                                                    .add(
                                                        model: RatingModel(
                                                            bookingId: widget
                                                                .booknigId,
                                                            fitness:
                                                                fitness.text,
                                                            skill: skill.text,
                                                            speed: speed.text,
                                                            strength:
                                                                strength.text));
                                              }
                                            },
                                            text: "Add",
                                          ),
                                          const Gap(20),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              );
                            },
                            text: "Add Rate"),
                      ),
                      const Spacer(),
                    ],
                  ),
                );
              } else {
                return Container();
              }
            },
          )),
    );
  }
}
