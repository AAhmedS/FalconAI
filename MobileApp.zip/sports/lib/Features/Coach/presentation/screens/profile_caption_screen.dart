import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/Services/app_pref.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/resources/images.dart';
import 'package:sports/Features/onBoarding/presentation/screens/splash_screen.dart';

class ProfileCaptionScreen extends StatelessWidget {
  const ProfileCaptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Text(
                  "zyad mohamed",
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Gap(10),
                Container(
                    width: 100,
                    height: 100,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: const Color(0xFF3252A6), width: 3),
                    ),
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: NetworkImage(
                              "https://t4.ftcdn.net/jpg/03/64/21/11/360_F_364211147_1qgLVxv1Tcq0Ohz3FawUfrtONzz8nq3e.jpg"),
                          fit: BoxFit.cover,
                        ),
                      ),
                    )),
              ],
            ),
            const Gap(30),
            const Text(
              "الاعدادات",
              style: TextStyle(
                fontSize: 12,
                color: Color(0xffBBBBBB),
                fontWeight: FontWeight.bold,
              ),
            ),
            GestureDetector(
              onTap: () {
                CacheHelper.logout();
                context.pushAndRemoveUntil(const SplashScreen());
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color(0xFFF6F6F6),
                ),
                child: Row(
                  children: [
                    const Spacer(),
                    const Text(
                      "تسجيل خروج",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    const Gap(8),
                    Image.asset(AppImages.logoutIcon)
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileButtonCard extends StatelessWidget {
  const ProfileButtonCard(
      {super.key, required this.title, required this.image, this.onTap});
  final String title;
  final String image;
  final void Function()? onTap;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xFFF6F6F6),
        ),
        child: Row(
          children: [
            const Icon(
              Icons.arrow_back_ios,
              size: 18,
              color: Color(0xFF3252A6),
            ),
            const Spacer(),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Gap(8),
            Image.asset(
              image,
              color: const Color(0xFF3252A6),
            ),
          ],
        ),
      ),
    );
  }
}
