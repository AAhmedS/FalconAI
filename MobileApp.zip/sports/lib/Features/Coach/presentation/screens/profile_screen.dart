import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/Services/app_pref.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Features/onBoarding/presentation/screens/on_boarding_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  width: double.infinity,
                  height: 40,
                ),
                Align(
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: Colors.red),
                  ),
                ),
                const Gap(10),
                const Align(
                    child: Text(
                  "zyad mohamed",
                  style: TextStyle(fontSize: 20),
                )),
                const Gap(30),
                const Text(
                  "Edit Profile",
                  style: TextStyle(fontSize: 15),
                ),
                const Gap(
                  10,
                ),
                const Text(
                  "Setting",
                  style: TextStyle(fontSize: 15),
                ),
                const Gap(
                  10,
                ),
                GestureDetector(
                  onTap: () {
                    CacheHelper.logout();
                    context.pushAndRemoveUntil(OnBoardingScreen());
                  },
                  child: const Text(
                    "Logout",
                    style: TextStyle(fontSize: 15, color: Colors.red),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
