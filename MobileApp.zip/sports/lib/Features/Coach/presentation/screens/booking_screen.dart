import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Core/widgets/swap_widget.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_active_booking_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_not_active_booking_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/pass_cubit.dart';
import 'package:sports/Features/Coach/presentation/widgets/booking_widget.dart';
import 'package:sports/Features/Coach/presentation/widgets/coach_info_widget.dart';

class BookingScreen extends StatelessWidget {
  const BookingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: BlocListener<PassCubit, CoachState>(
        listener: (context, state) {
          if (state is SuccessPassFirstTestState) {
            successToast(context: context, message: "Success Pass First Text");
          }
          if (state is SuccessPassSecondTestState) {
            successToast(context: context, message: "Success Pass Second Text");
          }
          if (state is FailureCoachState) {
            errorToast(context: context, message: state.message);
          }
        },
        child: SingleChildScrollView(
          child: Column(
            children: [
              const Gap(20),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 15),
                child: CoachInfoWidget(),
              ),
              const Gap(20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SwapWidget(
                  firstTite: "الحجوزات الغير نشطة",
                  secondTitle: "الحجوزات النشطة",
                  firstWidget: BlocBuilder<GetAllActiveBookingCubit, CoachState>(
                    builder: (context, state) {
                      if (state is LoadingCoachState) {
                        return const LoadingWidget();
                      }
                      if (state is SuccessGetAllActiveBookingsState) {
                        return SingleChildScrollView(
                          child: Column(
                            children: state.list.map(
                              (e) {
                                return BookingWidget(
                                  model: e,
                                  bookingId: e.bookingId!,
                                  playerId: e.playerId!,
                                );
                              },
                            ).toList(),
                          ),
                        );
                      } else {
                        return Container();
                      }
                    },
                  ),
                  secondWidget:
                      BlocBuilder<GetAllNotActiveBookingCubit, CoachState>(
                    builder: (context, state) {
                      if (state is LoadingCoachState) {
                        return const LoadingWidget();
                      }
                      if (state is SuccessGetAllNotActiveBookingsState) {
                        return SingleChildScrollView(
                          child: Column(
                            children: state.list.map(
                              (e) {
                                return BookingWidget(
                                  model: e,
                                  bookingId: e.bookingId!,
                                  playerId: e.playerId!,
                                );
                              },
                            ).toList(),
                          ),
                        );
                      } else {
                        return Container();
                      }
                    },
                  ),
                ),
              ),
              const Gap(20),
            ],
          ),
        ),
      )),
    );
  }
}
