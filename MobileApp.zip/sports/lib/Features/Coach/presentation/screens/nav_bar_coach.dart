import 'package:flutter/material.dart';
import 'package:sports/Core/resources/images.dart';
import 'package:sports/Features/Coach/presentation/screens/all_activity_screen_.dart';
import 'package:sports/Features/Coach/presentation/screens/booking_screen.dart';
import 'package:sports/Features/Coach/presentation/screens/home_screen.dart';
import 'package:sports/Features/Coach/presentation/screens/profile_caption_screen.dart';

class NavBarCoach extends StatefulWidget {
  const NavBarCoach({super.key});

  @override
  State<NavBarCoach> createState() => _NavBarCoachState();
}

class _NavBarCoachState extends State<NavBarCoach> {
  List icons = [
    AppImages.home,
    AppImages.bookingIcon,
    AppImages.sportsIcon,
    AppImages.profileIcon,
  ];
  List pages = [
    const CoachHomeScreen(),
    const BookingScreen(),
    AllActivityScreen(),
    const ProfileCaptionScreen(),
  ];
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ...List.generate(
                icons.length,
                (index) {
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedIndex = index;
                      });
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.asset(
                          icons[index],
                          color: selectedIndex == index
                              ? const Color(0xff335199)
                              : Colors.black,
                        )
                      ],
                    ),
                  );
                },
              )
            ],
          ),
        ),
        body: pages[selectedIndex]);
  }
}
