import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:intl/intl.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/resources/color.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/activity_coash_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/get_all_activity%20_cubit.dart';
import 'package:sports/Features/Coach/presentation/widgets/activity_card.dart';

class AllActivityScreen extends StatefulWidget {
  const AllActivityScreen({super.key, required this.bookingId});
  final int bookingId;

  @override
  State<AllActivityScreen> createState() => _AllActivityScreenState();
}

class _AllActivityScreenState extends State<AllActivityScreen> {
  @override
  void initState() {
    super.initState();
    context
        .read<GetAllActivityCubit>()
        .getAllActivities(bookingId: widget.bookingId);
  }

  TextEditingController title = TextEditingController();
  TextEditingController description = TextEditingController();
  DateTime? attendanceDate;
  GlobalKey<FormState> formKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          floatingActionButton: GestureDetector(
            onTap: () {
              showModalBottomSheet(
                context: context,
                builder: (context) {
                  return Form(
                    key: formKey,
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      color: Colors.white,
                      child: Column(
                        children: [
                          CustomTextField(
                            hintText: "Title",
                            controller: title,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "This field is required.";
                              }
                              return null;
                            },
                          ),
                          const Gap(20),
                          CustomTextField(
                            hintText: "Description",
                            controller: description,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "This field is required.";
                              }
                              return null;
                            },
                          ),
                          const Gap(20),
                          StatefulBuilder(
                            builder: (context, setStates) {
                              return CustomTextField(
                                onTap: () async {
                                  var pickedDate = await showDatePicker(
                                    context: context,
                                    firstDate: DateTime.now(),
                                    lastDate: DateTime(2000000),
                                  );
                                  if (pickedDate != null) {
                                    attendanceDate = pickedDate;
                                    setStates(() {});
                                  }
                                },
                                hintText: attendanceDate == null
                                    ? "Attendance Date"
                                    : DateFormat('yyyy-MM-dd')
                                        .format(attendanceDate!),
                                controller: TextEditingController(),
                                readOnly: true,
                                validator: (value) {
                                  if (attendanceDate == null) {
                                    return "This field is required.";
                                  }
                                  return null;
                                },
                              );
                            },
                          ),
                          const Spacer(),
                          CustomButton(
                            onTap: () {
                              if (formKey.currentState?.validate() == true) {
                                context.read<ActivityCoashCubit>().addActivity(
                                      model: ActivityModel(
                                          bookingId: widget.bookingId,
                                          description: description.text,
                                          title: title.text,
                                          attendanceDate: attendanceDate),
                                    );
                                context.pop();
                              }
                            },
                            text: "Add",
                          )
                        ],
                      ),
                    ),
                  );
                },
              );
            },
            child: Container(
              width: 50,
              height: 50,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: AppColor.primaryColor1),
              child: const Center(
                child: Icon(
                  Icons.add,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          body: BlocConsumer<ActivityCoashCubit, CoachState>(
            listener: (context, state) {
              if (state is SuccessAddActivityState) {
                successToast(context: context, message: "Success Add Activity");
                context
                    .read<GetAllActivityCubit>()
                    .getAllActivities(bookingId: widget.bookingId);
              }
              if (state is SuccessDeleteActivityState) {
                successToast(
                    context: context, message: "Success Delete Activity");
                context
                    .read<GetAllActivityCubit>()
                    .getAllActivities(bookingId: widget.bookingId);
              }
            },
            builder: (context, state) {
              if (state is LoadingCoachState) {
                return const LoadingWidget();
              }
              return BlocBuilder<GetAllActivityCubit, CoachState>(
                builder: (context, state) {
                  if (state is LoadingCoachState) {
                    return const LoadingWidget();
                  }
                  if (state is SuccessGetAllActivitiesState) {
                    return SingleChildScrollView(
                      child: Column(
                        children: state.list.map(
                          (e) {
                            return ActivityCard(
                              model: e,
                            );
                          },
                        ).toList(),
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              );
            },
          )),
    );
  }
}
