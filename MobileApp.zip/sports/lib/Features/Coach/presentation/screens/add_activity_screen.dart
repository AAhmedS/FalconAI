import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/extensions.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/activity_coash_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';

class AddActivityScreen extends StatefulWidget {
  const AddActivityScreen({super.key, required this.bookingId});
  final int bookingId;
  @override
  State<AddActivityScreen> createState() => _AddActivityScreenState();
}

class _AddActivityScreenState extends State<AddActivityScreen> {
  TextEditingController title = TextEditingController();
  TextEditingController description = TextEditingController();
  TextEditingController attendanceDateController = TextEditingController();
  DateTime? attendanceDate;
  GlobalKey<FormState> formKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: BlocConsumer<ActivityCoashCubit, CoachState>(
      listener: (context, state) {
        if (state is SuccessAddActivityState) {
          successToast(context: context, message: "Success Add Activity");
        }
        if (state is FailureCoachState) {
          errorToast(context: context, message: state.message);
        }
      },
      builder: (context, state) {
        return Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const Gap(50),
                Row(
                  children: [
                    const Spacer(),
                    const Text(
                      "أضافة اختبار",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {
                        context.pop();
                      },
                      child: const Icon(Icons.arrow_forward_ios_outlined),
                    ),
                    const Gap(10),
                  ],
                ),
                const Gap(30),
                CustomTextField(
                  hintText: "Title",
                  controller: title,
                  validator: (value) => value.isValid(),
                ),
                const Gap(25),
                CustomTextField(
                  hintText: "Description",
                  controller: description,
                  validator: (value) => value.isValid(),
                ),
                const Gap(25),
                CustomTextField(
                  validator: (value) {
                    if (attendanceDate == null) {
                      return "مطلوب";
                    }
                    return null;
                  },
                  onTap: () async {
                    var pickedDate = await showDatePicker(
                        context: context,
                        firstDate: DateTime.now(),
                        lastDate: DateTime(3000, 2, 2));
                    if (pickedDate != null) {
                      attendanceDate = pickedDate;
                      log(attendanceDate.toString());
                      log(widget.bookingId.toString());
                    }
                  },
                  hintText: "Attendance Date",
                  controller: attendanceDateController,
                  readOnly: true,
                ),
                const Spacer(),
                CustomButton(
                    onTap: () {
                      if (formKey.currentState?.validate() == true) {
                        context.read<ActivityCoashCubit>().addActivity(
                                model: ActivityModel(
                              attendanceDate: attendanceDate,
                              bookingId: widget.bookingId,
                              title: title.text,
                              description: description.text,
                            ));
                      }
                    },
                    text: "اضافة"),
                const Gap(40)
              ],
            ),
          ),
        );
      },
    ));
  }
}
