import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/swap_widget.dart';
import 'package:sports/Features/Coach/presentation/widgets/coach_info_widget.dart';
import 'package:sports/Features/Coach/presentation/widgets/news_card.dart';
import 'package:sports/Features/Player/presentation/cubit/get_news_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/get_videos_cubit.dart';
import 'package:sports/Features/Player/presentation/cubit/player_cubit.dart';
import 'package:sports/Features/Player/presentation/screens/videos_screen.dart';

class CoachHomeScreen extends StatelessWidget {
  const CoachHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          // Wrap the content with SingleChildScrollView for scrolling
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const CoachInfoWidget(),
                const Gap(30),
                SwapWidget(
                    firstTite: "اخر الاخبار",
                    firstWidget: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text(
                          "اخر الاخبار",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Gap(20),
                        BlocBuilder<GetNewsCubit, PlayerState>(
                          builder: (context, state) {
                            if (state is LoadingPlayerState) {
                              return const LoadingWidget();
                            }
                            if (state is SuccessGetNewsState) {
                              return Column(
                                children: state.list.map(
                                  (e) {
                                    return NewsCard(model: e);
                                  },
                                ).toList(),
                              );
                            } else {
                              return Container();
                            }
                          },
                        ),
                      ],
                    ),
                    secondTitle: "الفيديوهات",
                    secondWidget: BlocBuilder<GetVideosCubit, PlayerState>(
                      builder: (context, state) {
                        if (state is LoadingPlayerState) {
                          return const LoadingWidget();
                        }
                        if (state is SuccessGetVideosState) {
                          return Column(
                            children: state.list
                                .map(
                                  (e) =>
                                      VideoWidget(videoUrl: e.videoPath ?? ""),
                                )
                                .toList(),
                          );
                        } else {
                          return Container();
                        }
                      },
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
