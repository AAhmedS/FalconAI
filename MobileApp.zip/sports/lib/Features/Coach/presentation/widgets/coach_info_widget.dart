import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class CoachInfoWidget extends StatelessWidget {
  const CoachInfoWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        const Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              "مرحبا",
              style: TextStyle(
                fontSize: 14,
                color: Color(0xff383838),
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              "zyad mohamed",
              style: TextStyle(
                fontSize: 18,
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const Gap(10),
        Container(
          width: 57,
          height: 57,
          decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
              image: DecorationImage(
                image: NetworkImage(
                    "https://plus.unsplash.com/premium_photo-1689568158814-3b8e9c1a9618?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cGVyc29uYXxlbnwwfHwwfHx8MA%3D%3D"),
                fit: BoxFit.cover,
              )),
        ),
      ],
    );
  }
}
