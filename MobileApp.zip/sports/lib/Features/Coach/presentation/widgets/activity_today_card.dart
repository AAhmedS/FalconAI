import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:readmore/readmore.dart';
import 'package:sports/Features/Coach/models/activity_today_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/activity_coash_cubit.dart';
import 'package:sports/Features/Coach/presentation/cubit/present_activities_cubit.dart';
import 'package:sports/Features/Coach/presentation/widgets/booking_widget.dart';

class ActivityTodayCard extends StatefulWidget {
  const ActivityTodayCard({super.key, required this.model});
  final ActivityTodayModel model;

  @override
  State<ActivityTodayCard> createState() => _ActivityTodayCardState();
}

class _ActivityTodayCardState extends State<ActivityTodayCard> {
  bool active = false;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: const [
                  BoxShadow(color: Colors.black12, blurRadius: 30)
                ]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    DropdownButton2(
                      dropdownStyleData: DropdownStyleData(
                          width: 150,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10))),
                      onChanged: (value) {
                        if (value == "حذف") {
                          context.read<ActivityCoashCubit>().deleteActivity(
                              activityId: widget.model.activityId!);
                        }
                      },
                      items: const [
                        DropdownMenuItem(
                          value: "حذف",
                          child: Text(
                            "حذف",
                            style: TextStyle(fontSize: 14, color: Colors.black),
                          ),
                        ),
                        DropdownMenuItem(
                          value: "تعديل",
                          child: Text(
                            "تعديل",
                            style: TextStyle(fontSize: 14, color: Colors.black),
                          ),
                        ),
                      ],
                      customButton: Container(
                        width: 25,
                        height: 25,
                        decoration: const BoxDecoration(
                            shape: BoxShape.circle, color: Color(0xff3352A3)),
                        child: const Center(
                          child: Icon(
                            Icons.add,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                      underline: Container(),
                    ),
                    const Spacer(),
                    Column(
                      children: [
                        const Text(
                          "اسم النشاط",
                          style:
                              TextStyle(fontSize: 10, color: Color(0xff6A707C)),
                        ),
                        Text(
                          widget.model.title ?? "",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const Gap(20),
                ReadMoreText(
                  widget.model.description ?? "",
                  style: const TextStyle(fontSize: 10),
                  textAlign: TextAlign.end,
                ),
                const Gap(10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    BookingItems(
                        title: "الحضور", value: widget.model.attendance ?? ""),
                    const Gap(20),
                    // BookingItems(
                    //     title: "تاريخ الحضور",
                    //     value: ),
                  ],
                )
              ],
            ),
          ),
        ),
        Checkbox(
          value: active,
          onChanged: (value) {
            setState(() {
              active = value ?? false;
              if (active) {
                context
                    .read<PresentActivitiesCubit>()
                    .add(id: widget.model.activityId!);
              } else {
                context
                    .read<PresentActivitiesCubit>()
                    .remove(id: widget.model.activityId!);
              }
            });
          },
        ),
      ],
    );
  }
}
