import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:readmore/readmore.dart';
import 'package:sports/Features/Player/models/news_model.dart';

class NewsCard extends StatelessWidget {
  const NewsCard({super.key, required this.model});
  final NewsModel model;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
          color: const Color(0xffF4F4F4),
          borderRadius: BorderRadius.circular(8)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            model.title ?? "",
            style: const TextStyle(fontSize: 14),
            textAlign: TextAlign.end,
          ),
          const Gap(10),
          ReadMoreText(
            model.description ?? "",
            style: const TextStyle(fontSize: 10, color: Color(0xffAAAAAA)),
            textAlign: TextAlign.end,
          ),
        ],
      ),
    );
  }
}
