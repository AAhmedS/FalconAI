import 'dart:io';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/pass_cubit.dart';
import 'package:sports/Features/Coach/presentation/screens/add_activity_screen.dart';
import 'package:sports/Features/Coach/presentation/screens/all_activity_screen.dart';
import 'package:sports/Features/Coach/presentation/widgets/add_review_widget.dart';
import 'package:sports/Features/Coach/presentation/widgets/add_video_to_player_widget.dart';
import 'package:video_player/video_player.dart';

class BookingWidget extends StatelessWidget {
  BookingWidget(
      {super.key,
      required this.bookingId,
      required this.playerId,
      required this.model,
      this.isPlayer = false});
  final int bookingId;
  GlobalKey<FormState> formKeyVideo = GlobalKey();
  File? video;
  bool isPlayer;
  late VideoPlayerController videoPlayerController;
  TextEditingController description = TextEditingController();
  final String playerId;
  final BookingModel model;
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PassCubit, CoachState>(
      builder: (context, state) {
        if (state is LoadingCoachState) {
          return const LoadingWidget();
        }
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 30)
              ]),
          child: Column(
            children: [
              Row(
                children: [
                  DropdownButton2(
                    dropdownStyleData: DropdownStyleData(
                        width: 150,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10))),
                    onChanged: (value) {
                      if (value == 'اضافة اختبار') {
                        context.push(AddActivityScreen(
                          bookingId: bookingId,
                        ));
                      }
                      if (value == 'النشاطات') {
                        context.push(AllActivityScreen(
                          bookingId: bookingId,
                        ));
                      }
                      if (value == "اضافة تقييم") {
                        showModalBottomSheet(
                          context: context,
                          builder: (context) {
                            return StatefulBuilder(
                              builder: (context, setStates) {
                                return AddReviewWidget(
                                  bookingId: bookingId,
                                );
                              },
                            );
                          },
                        );
                      }
                      if (value == "رفع فيديو") {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              content:
                                  AddVideoToPlayerWidget(playerId: playerId),
                            );
                          },
                        );
                      }
                      if (value == "اجتياز النشاط الثاني") {
                        context
                            .read<PassCubit>()
                            .passSecondTest(bookingId: bookingId);
                      }
                      if (value == "اجتياز النشاط الاول") {
                        context
                            .read<PassCubit>()
                            .passFirstTest(bookingId: bookingId);
                      }
                    },
                    items: [
                      // DropdownMenuItem(
                      //   value: "تسجيل حضور",
                      //   child: Text(
                      //     "تسجيل حضور",
                      //     style: TextStyle(fontSize: 14, color: Colors.black),
                      //   ),
                      // ),
                      // DropdownMenuItem(
                      //   value: "تسجيل غياب",
                      //   child: Text(
                      //     "تسجيل غياب ",
                      //     style: TextStyle(fontSize: 14, color: Colors.black),
                      //   ),
                      // ),
                      const DropdownMenuItem(
                        value: "النشاطات",
                        child: Text(
                          "النشاطات",
                          style: TextStyle(fontSize: 14, color: Colors.black),
                        ),
                      ),
                      if (!isPlayer)
                        const DropdownMenuItem(
                          value: "اضافة تقييم",
                          child: Text(
                            "اضافة تقييم",
                            style: TextStyle(fontSize: 14, color: Colors.black),
                          ),
                        ),

                      const DropdownMenuItem(
                        value: "رفع فيديو",
                        child: Text(
                          "رفع فيديو",
                          style: TextStyle(fontSize: 14, color: Colors.black),
                        ),
                      ),
                      const DropdownMenuItem(
                        value: "اجتياز النشاط الاول",
                        child: Text(
                          "اجتياز النشاط الاول",
                          style: TextStyle(fontSize: 14, color: Colors.black),
                        ),
                      ),
                      const DropdownMenuItem(
                        value: "اجتياز النشاط الثاني",
                        child: Text(
                          "اجتياز النشاط الثاني",
                          style: TextStyle(fontSize: 14, color: Colors.black),
                        ),
                      )
                    ],
                    customButton: Container(
                      width: 25,
                      height: 25,
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: Color(0xff3352A3)),
                      child: const Center(
                        child: Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                    underline: Container(),
                  ),
                  const Spacer(),
                  const Column(
                    children: [
                      Text(
                        "اسم الاعب",
                        style:
                            TextStyle(fontSize: 10, color: Color(0xff6A707C)),
                      ),
                      Text(
                        "زياد محمد",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const Gap(20),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  BookingItems(title: "جلسات غابو عنها", value: model.absentSessions.toString()),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      BookingItems(title: "جلسات تم حضورها", value: model.presentSessions.toString()),
                      const Gap(4),
                      BookingItems(title: "تاريخ انتهاء الحجز", value: model.endAt.toString()),
                    ],
                  ),
                  const Gap(5),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      BookingItems(title: "عدد الجلسات الكلية", value: model.numberOfSessions.toString()),
                      const Gap(4),
                      BookingItems(title: "تاريخ الحجز", value: model.startAt.toString()),
                    ],
                  ),
                ],
              )
            ],
          ),
        );
      },
    );
  }
}

class BookingItems extends StatelessWidget {
  const BookingItems({super.key, required this.title, required this.value});
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 12, color: Color(0xff6A707C)),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
