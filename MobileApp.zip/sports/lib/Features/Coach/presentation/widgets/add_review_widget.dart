import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:sports/Core/function/extensions.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/loading_widget.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Coach/models/rating_model.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/rate_player_coach_cubit.dart';

class AddReviewWidget extends StatelessWidget {
  AddReviewWidget({super.key, required this.bookingId});
  final int bookingId;
  TextEditingController fitness = TextEditingController();
  TextEditingController strength = TextEditingController();
  TextEditingController speed = TextEditingController();
  TextEditingController skill = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<RatePlayerCoachCubit, CoachState>(
      listener: (context, state) {
        if (state is SuccessAddRatePlayerState) {
          context.pop();
          successToast(context: context, message: "Success Add Rview");
        }
        if (state is FailureCoachState) {
          errorToast(context: context, message: state.message);
        }
      },
      builder: (context, state) {
        if (state is LoadingCoachState) {
          return const LoadingWidget();
        }
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(25),
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20), topRight: Radius.circular(20))),
          child: Form(
            key: formKey,
            child: Column(
              children: [
                CustomTextField(
                    validator: (value) => value.isValid(),
                    hintText: "Fitness",
                    controller: fitness),
                const Gap(30),
                CustomTextField(
                    validator: (value) => value.isValid(),
                    hintText: "Speed",
                    controller: speed),
                const Gap(30),
                CustomTextField(
                    validator: (value) => value.isValid(),
                    hintText: "Strength",
                    controller: strength),
                const Gap(30),
                CustomTextField(
                    validator: (value) => value.isValid(),
                    hintText: "Skill",
                    controller: skill),
                const Spacer(),
                CustomButton(
                    onTap: () {
                      if (formKey.currentState?.validate() == true) {
                        context.read<RatePlayerCoachCubit>().add(
                              model: RatingModel(
                                bookingId: bookingId,
                                fitness: fitness.text,
                                skill: skill.text,
                                speed: speed.text,
                                strength: strength.text,
                              ),
                            );
                      }
                    },
                    text: "Add Review")
              ],
            ),
          ),
        );
      },
    );
  }
}
