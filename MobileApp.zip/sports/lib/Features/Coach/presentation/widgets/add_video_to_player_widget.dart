import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sports/Core/function/navigation.dart';
import 'package:sports/Core/resources/color.dart';
import 'package:sports/Core/widgets/custom_button.dart';
import 'package:sports/Core/widgets/custom_text_field.dart';
import 'package:sports/Core/widgets/error_toast.dart';
import 'package:sports/Core/widgets/success_toast.dart';
import 'package:sports/Features/Coach/presentation/cubit/coach_state.dart';
import 'package:sports/Features/Coach/presentation/cubit/video_player_cubit.dart';
import 'package:video_player/video_player.dart';

class AddVideoToPlayerWidget extends StatelessWidget {
  AddVideoToPlayerWidget({super.key, required this.playerId});
  GlobalKey<FormState> formKeyVideo = GlobalKey();
  File? video;
  late VideoPlayerController videoPlayerController;
  TextEditingController description = TextEditingController();
  final String playerId;
  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(
      builder: (context, setStatee) {
        return BlocConsumer<VideoPlayerCubit, CoachState>(
          listener: (context, state) {
            if (state is SuccessAddVideoToPlayerState) {
              context.pop();
              successToast(context: context, message: "Success Add Video");
            }
            if (state is FailureCoachState) {
              errorToast(context: context, message: state.message);
            }
          },
          builder: (context, state) {
            if (state is LoadingCoachState) {
              return const SizedBox(
                height: 150,
                child: Center(
                  child: CircularProgressIndicator(
                    color: AppColor.primaryColor1,
                  ),
                ),
              );
            }
            return Form(
              key: formKeyVideo,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FormField(
                    validator: (value) {
                      if (video == null) {
                        return "This Feild is required";
                      }
                      return null;
                    },
                    builder: (field) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onTap: () async {
                              if (video == null) {
                                var picekdVideo = await ImagePicker()
                                    .pickVideo(source: ImageSource.gallery);
                                if (picekdVideo != null) {
                                  setStatee(() {
                                    video = File(picekdVideo.path);
                                    videoPlayerController =
                                        VideoPlayerController.file(video!)
                                          ..initialize().then(
                                            (value) {
                                              setStatee(() {});
                                            },
                                          );
                                  });
                                }
                              }
                            },
                            child: Container(
                                width: double.infinity,
                                height: 200,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    border: Border.all()),
                                child: video != null
                                    ? videoPlayerController.value.isInitialized
                                        ? AspectRatio(
                                            aspectRatio: videoPlayerController
                                                .value.aspectRatio,
                                            child: VideoPlayer(
                                                videoPlayerController),
                                          )
                                        : null
                                    : const Center(
                                        child: Icon(
                                          Icons.camera_alt_rounded,
                                          size: 50,
                                        ),
                                      )),
                          ),
                          if (field.hasError)
                            Column(
                              children: [
                                const Gap(8),
                                Text(
                                  field.errorText ?? "",
                                  style: const TextStyle(color: Colors.red),
                                )
                              ],
                            )
                        ],
                      );
                    },
                  ),
                  const Gap(30),
                  CustomTextField(
                    hintText: "Description",
                    controller: description,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "This field is required.";
                      }
                      return null;
                    },
                  ),
                  const Gap(30),
                  CustomButton(
                    onTap: () async {
                      if (formKeyVideo.currentState?.validate() == true) {
                        context.read<VideoPlayerCubit>().uploadVideo(
                            description: description.text,
                            video: video!,
                            playerId: playerId);
                      }
                    },
                    text: "Upload",
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }
}
