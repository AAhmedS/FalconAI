import 'dart:io';

import 'package:dio/dio.dart';
import 'package:sports/Core/Services/api_client_helper.dart';
import 'package:sports/Core/resources/endpoints.dart';
import 'package:sports/Features/Coach/models/rating_model.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';

class CoachDataSource {
  final ApiClientHelper api;

  CoachDataSource({required this.api});

  Future getAllActiveBookings() {
    return api.get(url: Endpoints.getAllActiveBookings);
  }

  Future getAllNotActiveBookings() {
    return api.get(url: Endpoints.getAllNotActiveBookings);
  }

  Future getAllActivities({required int bookingId}) {
    return api.get(
        url: Endpoints.getAllActivitiesCaptain,
        queryParameters: {"BookingId": bookingId});
  }

  Future getActivity({required int activityId}) {
    return api.get(
        url: Endpoints.getActivityCaptain,
        queryParameters: {"ActivityId": activityId});
  }

  Future addActivity({required ActivityModel model}) {
    return api.post(
        url: Endpoints.addActivity, data: FormData.fromMap(model.create()));
  }

  Future updateActivity({required ActivityModel model}) {
    return api.put(
        url: Endpoints.updateActivity,
        data: model.update(),
        queryParameters: {"ActivityId": model.id});
  }

  Future deleteActivity({required int activityId}) {
    return api.delete(
        url: Endpoints.deleteActivity,
        queryParameters: {"ActivityId": activityId});
  }

  Future markAttendanceAsPresent({required int activityId}) {
    return api.put(
        url: Endpoints.markAttendanceAsPresent,
        queryParameters: {"ActivityId": activityId});
  }

  Future markAttendanceAsAbsent({required int activityId}) {
    return api.put(
        url: Endpoints.markAttendanceAsAbsent,
        queryParameters: {"ActivityId": activityId});
  }

  Future getRatePlayer({required int bookingId}) {
    return api.get(
        url: Endpoints.getRatePlayer,
        queryParameters: {"BookingId": bookingId});
  }

  Future addRatePlayer({required RatingModel model}) {
    return api.post(
        url: Endpoints.addRatePlayer,
        queryParameters: {"BookingId": model.bookingId},
        data: model.create());
  }

  Future updateRatePlayer({required RatingModel model}) {
    return api.post(
        url: Endpoints.updateRatePlayer,
        queryParameters: {"RateId": model.id},
        data: model.update());
  }

  Future getPlayerVideos({required int playerId}) {
    return api.get(
        url: Endpoints.getPlayerVideos,
        queryParameters: {"PlayerId": playerId});
  }

  Future addVideoToPlayer(
      {required String playerId,
      required String description,
      required File video}) async {
    FormData formData = FormData.fromMap({
      "Description": description,
      "Video": await MultipartFile.fromFile(video.path)
    });
    return api.post(
        url: Endpoints.addVideoToPlayer,
        queryParameters: {"PlayerId": playerId},
        data: formData);
  }

  Future updateVideoPlayer(
      {required int videoId, required String description}) {
    return api.put(
        url: Endpoints.updateVideoPlayer,
        queryParameters: {"VideoId": videoId, "Description": description});
  }

  Future deleteVideoPlayer({required int videoId}) {
    return api.delete(
        url: Endpoints.deleteVideoPlayer,
        queryParameters: {"PlayerId": videoId});
  }

  Future getAllSportsForCaptain() {
    return api.get(url: Endpoints.getAllSportsForCaptain);
  }

  Future getSport({required int sportId}) {
    return api.get(
        url: Endpoints.getSportCaptain, queryParameters: {"SportId": sportId});
  }

  Future getPlayer({required String playerId}) {
    return api.get(
        url: Endpoints.getPlayerCaptain,
        queryParameters: {"PlayerId": playerId});
  }

  Future getAllActivitiesForToday(
      {bool? isPassFirstTest,
      bool? isPassSecondTest,
      int? minAge,
      int? maxAge}) {
    return api.get(url: Endpoints.getAllActivitiesForToday, queryParameters: {
      "isPassFirstTest": isPassFirstTest,
      "isPassSecondTest": isPassSecondTest,
      "minAge": minAge,
      "maxAge": maxAge,
      "Date": "11/2/2024"
    });
  }

  Future passFirstTest({required int bookingId}) {
    return api.put(
        url: Endpoints.passFirstTest,
        queryParameters: {"BookingId": bookingId});
  }

  Future passSecondTest({required int bookingId}) {
    return api.put(
        url: Endpoints.passSecondTest,
        queryParameters: {"BookingId": bookingId});
  }
  Future getProfile({required int bookingId}) {
    return api.put(
        url: Endpoints.passSecondTest,
        queryParameters: {"BookingId": bookingId});
  }
  Future absentActivites({required List<int> activityIds}) {
    return api.put(
        url: Endpoints.absentActivites,
        queryParameters: {"ActivityIds": activityIds});
  }
  Future presentActivities({required List<int> activityIds}) {
    return api.put(
        url: Endpoints.presentActivities,
        queryParameters: {"ActivityIds": activityIds});
  }
}
