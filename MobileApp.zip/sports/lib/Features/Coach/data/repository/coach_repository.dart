import 'dart:developer';
import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:sports/Core/Services/base_repository.dart';
import 'package:sports/Core/errors/failuer.dart';
import 'package:sports/Features/Coach/data/data_source/coach_data_source.dart';
import 'package:sports/Features/Coach/models/activity_model.dart';
import 'package:sports/Features/Coach/models/activity_today_model.dart';
import 'package:sports/Features/Coach/models/booking_model.dart';
import 'package:sports/Features/Coach/models/player_model.dart';
import 'package:sports/Features/Coach/models/rating_model.dart';
import 'package:sports/Features/Coach/models/sport_model.dart';

class CoachRepository {
  final CoachDataSource dataSource;
  final BaseRepository baseRepository;
  CoachRepository({required this.dataSource, required this.baseRepository});
  Future<Either<Failuer, List<BookingModel>>> getAllActiveBookings() async {
    var response =
        await baseRepository.repository(dataSource.getAllActiveBookings());
    return response.fold(
      (l) {
        log(l.message.toString(), name: "lskdjflskjflskdfjdddddd");
        return left(l);
      },
      (r) {
        log(r.toString(), name: "lskdjflsdkjfls");
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<BookingModel>>> getAllNotActiveBookings() async {
    var response =
        await baseRepository.repository(dataSource.getAllNotActiveBookings());
    return response.fold(
      (l) {
        log(l.message.toString(), name: "lskdjflskjflskdfjdddddd");
        return left(l);
      },
      (r) {
        log(r.toString(), name: "lskdjflsdkjfls");
        List<BookingModel> list = (r.data as List)
            .map(
              (e) => BookingModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, List<ActivityModel>>> getAllActivities(
      {required int bookingId}) async {
    var response = await baseRepository
        .repository(dataSource.getAllActivities(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<ActivityModel> list = (r.data as List)
            .map(
              (e) => ActivityModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, ActivityModel>> getActivity(
      {required int activityId}) async {
    var response = await baseRepository
        .repository(dataSource.getActivity(activityId: activityId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(ActivityModel.fromJson(r.data));
      },
    );
  }

  Future<Either<Failuer, String>> addActivity(
      {required ActivityModel model}) async {
    var response =
        await baseRepository.repository(dataSource.addActivity(model: model));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? "Success");
      },
    );
  }

  Future<Either<Failuer, String>> updateActivity(
      {required ActivityModel model}) async {
    var response = await baseRepository
        .repository(dataSource.updateActivity(model: model));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? "Success");
      },
    );
  }

  Future<Either<Failuer, String>> deleteActivity(
      {required int activityId}) async {
    var response = await baseRepository
        .repository(dataSource.deleteActivity(activityId: activityId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? "Success");
      },
    );
  }

  Future<Either<Failuer, String>> markAttendanceAsPresent(
      {required int activityId}) async {
    var response = await baseRepository
        .repository(dataSource.markAttendanceAsPresent(activityId: activityId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.data);
      },
    );
  }

  Future<Either<Failuer, String>> markAttendanceAsAbsent(
      {required int activityId}) async {
    var response = await baseRepository
        .repository(dataSource.markAttendanceAsAbsent(activityId: activityId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.data);
      },
    );
  }

  Future<Either<Failuer, String>> getRatePlayer(
      {required int bookingId}) async {
    var response = await baseRepository
        .repository(dataSource.getRatePlayer(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.data);
      },
    );
  }

  Future<Either<Failuer, String>> addRatePlayer(
      {required RatingModel model}) async {
    var response =
        await baseRepository.repository(dataSource.addRatePlayer(model: model));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? "Success");
      },
    );
  }

  Future<Either<Failuer, String>> updateRatePlayer(
      {required RatingModel model}) async {
    var response = await baseRepository
        .repository(dataSource.updateRatePlayer(model: model));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.data);
      },
    );
  }

  Future<Either<Failuer, String>> getPlayerVideos(
      {required int playerId}) async {
    var response = await baseRepository
        .repository(dataSource.getPlayerVideos(playerId: playerId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.data);
      },
    );
  }

  Future<Either<Failuer, String>> addVideoToPlayer(
      {required String playerId,
      required String description,
      required File video}) async {
    var response = await baseRepository.repository(dataSource.addVideoToPlayer(
        playerId: playerId, description: description, video: video));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? 'Success');
      },
    );
  }

  Future<Either<Failuer, String>> updateVideoPlayer(
      {required int videoId, required String description}) async {
    var response = await baseRepository.repository(dataSource.updateVideoPlayer(
        videoId: videoId, description: description));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? 'Success');
      },
    );
  }

  Future<Either<Failuer, String>> deleteVideoPlayer(
      {required int videoId}) async {
    var response = await baseRepository
        .repository(dataSource.deleteVideoPlayer(videoId: videoId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? 'Success');
      },
    );
  }

  Future<Either<Failuer, String>> getAllSportsForCaptain() async {
    var response =
        await baseRepository.repository(dataSource.getAllSportsForCaptain());
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(r.message ?? 'Success');
      },
    );
  }

  Future<Either<Failuer, SportModel>> getSport({required int sportId}) async {
    var response =
        await baseRepository.repository(dataSource.getSport(sportId: sportId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(SportModel.fromJson(r.data));
      },
    );
  }

  Future<Either<Failuer, PlayerModel>> getPlayer(
      {required String playerId}) async {
    var response = await baseRepository
        .repository(dataSource.getPlayer(playerId: playerId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right(PlayerModel.fromJson(r.data));
      },
    );
  }

  Future<Either<Failuer, List<ActivityTodayModel>>> getAllActivitiesForToday({
    bool? isPassFirstTest,
    bool? isPassSecondTest,
    int? minAge,
    int? maxAge,
  }) async {
    var response = await baseRepository.repository(
        dataSource.getAllActivitiesForToday(
            isPassFirstTest: isPassFirstTest,
            isPassSecondTest: isPassSecondTest,
            minAge: minAge,
            maxAge: maxAge));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        List<ActivityTodayModel> list = (r.data as List)
            .map(
              (e) => ActivityTodayModel.fromJson(e),
            )
            .toList();
        return right(list);
      },
    );
  }

  Future<Either<Failuer, String>> passFirstTest(
      {required int bookingId}) async {
    var response = await baseRepository
        .repository(dataSource.passFirstTest(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right("Success");
      },
    );
  }

  Future<Either<Failuer, String>> passSecondTest(
      {required int bookingId}) async {
    var response = await baseRepository
        .repository(dataSource.passSecondTest(bookingId: bookingId));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right("Success");
      },
    );
  }
  Future<Either<Failuer, String>> absentActivites(
      {required List<int> activityIds}) async {
    var response = await baseRepository
        .repository(dataSource.absentActivites(activityIds: activityIds));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right("Success");
      },
    );
  }
  Future<Either<Failuer, String>> presentActivities(
      {required List<int> activityIds}) async {
    var response = await baseRepository
        .repository(dataSource.presentActivities(activityIds: activityIds));
    return response.fold(
      (l) {
        return left(l);
      },
      (r) {
        return right("Success");
      },
    );
  }
}
